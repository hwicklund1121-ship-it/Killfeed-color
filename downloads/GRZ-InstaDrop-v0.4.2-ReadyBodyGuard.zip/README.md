# GRZ InstaDrop v0.4.2 ready body-exit guard test

The supplied v0.4.1 log confirms the build loaded and accepted 23 prone-target
callbacks. Of all 113 stance callbacks, 112 were allowed natively and one by
the legacy exception. There is no general prone-permission block in this run.
31 pre-command samples had preparation enabled, but intro/idle/prone-transition
tags were false in all 100 samples. This suggests a different active body path;
it does not prove it, since sampling time or tag propagation may be involved.

One native exit, Throwing -> IdleRas, has a standing/raised OR branch independent
of remaining animation time. This test wraps that original condition with a
phase guard: while TagThrowingIn or TagThrowingIdle is active, this one exit also
requires an explicit native throw cancellation command (-1). Outside those
phases the original exit is unchanged; original conditions remain necessary.
Other native exits, charge/release paths and custom roll exits are unchanged.

All other graph bytes match v0.4.1: native pose/strength chain and angle rules,
fast prone entry 0.22, roll-to-stand helper 0.24, source clips and roll guards.
No new fixed side/back pose or replacement native animation is added.

## Install

Close DayZ and stop the server, extract into a new folder, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires the current DayZ 1.30.164.289 / GRZ Movement local setup. Builds from
hash-checked current game files; native assets/user logs are not distributed.
Backups and rollback remain. Startup should identify `v0.4.2 graph selected`
and the Throwing -> IdleRas ready/intro guard.

## Test and capture

Stand still: G -> wait for lift -> look right -> prone. Hold the landing for
one second before roll or stand. Then test dropping during lift and while moving.
Check ordinary stance, both roll directions and mid-roll stand, then check that
G cancellation, manual weapon raise, charge/release and inventory cancellation
still exit gun-lift mode normally. Stop the test if preparation gets stuck;
restore the last working backup and send the current logs. Check another client.

New `drop-sample` logs run for at most 900 ms after accepted prone requests.
They include native LR/UD aim, separate script/weapon preparation flags,
on-back/roll state and control tags alongside intro/idle/throw-body tags. These
samples test whether the pre-command observations were simply too early and
whether native angle selection remains front-facing. Tags/angles are observed;
no keyboard synthesis, forced stance lock or position changes are added.
No player identifiers, positions or arbitrary text input are logged.

If the landing still differs, send the fresh script log and RPT plus a short
current-build clip. The guard is an unverified candidate fix, not a confirmed
engine diagnosis or exact 1.27 recreation. Native graph loading, Enforce
compilation, cancel/release behavior and visual/multiplayer motion need testing.

## Restore

Close both sides and run with a backup known to contain a working build:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL WORKING-BUILD BACKUP FOLDER"
```
