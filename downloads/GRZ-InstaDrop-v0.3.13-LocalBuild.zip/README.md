# GRZ InstaDrop v0.3.13 native graph type-error fix

The supplied v0.3.12 error log identifies two invalid graph expressions:
GRZDropNativeLeftSide and GRZDropNativeRightSide have Value X of type int,
while float is required. The graph is rejected, followed by an access violation
while the menu character is created. This package changes only the two graph
constants: -90 -> -90.0 and 90 -> 90.0. All other graph bytes remain unchanged.

The source change directly addresses those reported type errors. It has not
been compiled or loaded by the DayZ engine here; menu/login must be retested.
Static regression checks verify that both new pose constants are float literals,
and package hashes/PBO integrity are checked. These are not gameplay tests.

Retains the direct native side-pose selector from v0.3.12: right/neutral AimX
selects native X -90.0 (intended left-side landing), negative AimX selects
X 90.0. AimY, roll sources/guards, drop 0.22 and stand 0.24 remain unchanged.
Side anatomy, camera/body alignment and foot spin still require gameplay tests.

## Install

Close DayZ and stop the server. Extract into a new folder and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires the existing DayZ 1.30.164.289 / GRZ Movement local setup. Native
graphs are built locally from hash-checked game files; native assets and the
uploaded logs are not distributed. Installer backups/rollback remain included.
The broken v0.3.12 PBOs will be backed up and replaced on both sides.

## Check

Start DayZ and confirm the menu/login no longer crashes. Check the new RPT/error
log for any graph errors and the script log for `v0.3.13 graph selected`.
Only after loading succeeds, test G -> look right -> drop -> roll -> stand.
If it still crashes, send the fresh RPT/error/script/crash logs from that run.
The graph must pass native loading before further animation changes.

## Restore

To restore a prior working version, use the backup made before installing
v0.3.12 (not the backup that contains the broken v0.3.12 files). Close both
sides and run using that exact backup folder:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL WORKING-BUILD BACKUP FOLDER"
```
