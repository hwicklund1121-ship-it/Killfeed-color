////////////////////////////////////////////////////////////////////
//DeRap: PTRD-41\PTRD-41\config.bin
//Produced from mikero's Dos Tools Dll version 10.21
//https://mikero.bytex.digital/Downloads
//'now' is Wed Nov 04 03:50:04 2026 : 'file' last modified on Sat Oct 24 21:26:39 2026
////////////////////////////////////////////////////////////////////

#define _ARMA_

class CfgPatches
{
	class PTRD41
	{
		units[] = {};
		weapons[] = {"UAV_PTRD41"};
		requiredVersion = 0.1;
		requiredAddons[] = {"DZ_Data","DZ_Weapons_Firearms"};
		ammo[] = {};
	};
};
class Mode_Safe;
class Mode_SemiAuto;
class Mode_Burst;
class Mode_FullAuto;
class OpticsInfoRifle;
class cfgWeapons
{
	class BoltActionRifle_InnerMagazine_Base;
	class PTRD_41_Base: BoltActionRifle_InnerMagazine_Base
	{
		scope = 0;
		weight = 12000;
		model = "UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD41.p3d";
	    attachments[] = {"weaponWrap"};
		hiddenSelections[] = {"camo","camo2"};
		ironsightsExcludingOptics[] = {"GrozaOptic","KobraOptic"};
		chamberableFrom[] = {"UAV_Ammo_VULCAN"};
		simpleHiddenSelections[] = {"hide_barrel"};
		modes[] = {"Single"};
		itemSize[] = {10,2};
		absorbency = 0.1;
		repairableWithKits[] = {1};
		repairCosts[] = {50};
		DisplayMagazine = 0;
		PPDOFProperties[] = {1,0.5,50,160,4,10};
		WeaponLength = 0.934214;
		barrelArmor = 1.1111;
		initSpeedMultiplier = 1;
		chamberedRound = "";
		chamberSize = 1;
		magazineSwitchTime = 0.25;
		ejectType = 1;
		recoilModifier[] = {2,2,2};
		swayModifier[] = {1,1,1};
		dispersion = 0.0005;
		class Single: Mode_SemiAuto
		{
			soundSetShot[] = {"PTRD_41_Shot_SoundSet","PTRD_41_Shot_SoundSet","PTRD_41_Shot_SoundSet"};
			reloadTime = 1.4;
			recoil = "recoil_AKM";
			recoilProne = "recoil_AKM_prone";
			magazineSlot = "magazine";
		};
		class Particles
		{
			class OnFire
			{
				class MuzzleFlash
				{
					ignoreIfSuppressed = 1;
					overrideParticle = "weapon_shot_mosin9130_01";
				};
				class SmokeCloud
				{
					overrideParticle = "weapon_shot_winded_smoke";
				};
			};
			class OnOverheating
			{
				shotsToStartOverheating = 5;
				maxOverheatingValue = 20;
				overheatingDecayInterval = 1;
			};
			class OnBulletCasingEject
			{
				class ChamberSmokeRaise
				{
					overrideParticle = "weapon_shot_chamber_smoke_raise";
					overridePoint = "Nabojnicestart";
				};
			};
		};
		class OpticsInfo: OpticsInfoRifle
		{
			memoryPointCamera = "eye";
			modelOptics = "-";
			distanceZoomMin = 100;
			distanceZoomMax = 100;
			discreteDistance[] = {100,200,300,400,500,600,700,800,900,1000};
			discreteDistanceInitIndex = 0;
		};
		class AnimEvents
		{
			class SoundWeapon
			{
				class walkErc_L
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 1;
				};
				class walkErc_R
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_R_SoundSet";
					id = 2;
				};
				class runErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 3;
				};
				class runErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_R_SoundSet";
					id = 4;
				};
				class sprintErc_L
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 5;
				};
				class sprintErc_R
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 6;
				};
				class walkCro_L
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 21;
				};
				class walkCro_R
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 22;
				};
				class runCro_L
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 23;
				};
				class runCro_R
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 24;
				};
				class walkProne_L
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 31;
				};
				class walkProne_R
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 32;
				};
				class runProne_L
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 33;
				};
				class runProne_R
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 34;
				};
				class jumpErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 35;
				};
				class jumpErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 36;
				};
				class landFootErc_L
				{
					soundSet = "Weapon_Movement_HRifle_landFootErc_SoundSet";
					id = 37;
				};
				class landFootErc_R
				{
					soundSet = "Weapon_Movement_HRifle_landFootErc_SoundSet";
					id = 38;
				};
				class walkRasErc_L
				{
					soundSet = "Weapon_Movement_HRifle_walkRasErc_SoundSet";
					id = 51;
				};
				class walkRasErc_R
				{
					soundSet = "Weapon_Movement_HRifle_walkRasErc_SoundSet";
					id = 52;
				};
				class runRasErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runRasErc_SoundSet";
					id = 53;
				};
				class runRasErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runRasErc_SoundSet";
					id = 54;
				};
				class HandStep_L
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 61;
				};
				class HandStep_R
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 62;
				};
				class HandStep_Hard_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 63;
				};
				class HandStep_Hard_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 64;
				};
				class landFeetErc
				{
					soundSet = "Weapon_Movement_HRifle_landFeetErc_SoundSet";
					id = 100;
				};
				class Weapon_Movement_HRifle_Walk
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 101;
				};
				class Weapon_Movement_HRifle_Run
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 102;
				};
				class Weapon_Movement_HRifle_Sprint
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 103;
				};
				class Weapon_Movement_HRifle_Land
				{
					soundSet = "Weapon_Movement_HRifle_landFeetErc_SoundSet";
					id = 104;
				};
				class Char_Gestures_Hand_Grab_Rifle
				{
					soundSet = "Char_Gestures_Hand_Grab_FabricRifle_SoundSet";
					id = 892;
				};
			};
		};
		class DamageSystem
		{
			class GlobalHealth
			{
				class Health
				{
					hitpoints = 2500;
					healthLevels[] = {{1.01,{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD.rvmat","UAVWEAPONS\PTRD-41\PTRD-41\data\Bolt.rvmat"}},{0.7,{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD.rvmat","UAVWEAPONS\PTRD-41\PTRD-41\data\Bolt.rvmat"}},{0.5,{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_damage.rvmat","UAVWEAPONS\PTRD-41\PTRD-41\data\Bolt_damage.rvmat"}},{0.3,{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_damage.rvmat","UAVWEAPONS\PTRD-41\PTRD-41\data\Bolt_damage.rvmat"}},{0.01,{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_destruct.rvmat","UAVWEAPONS\PTRD-41\PTRD-41\data\Bolt_destruct.rvmat"}}};
				};
			};
		};
	};
	class UAV_PTRD41: PTRD_41_Base
	{
		scope = 2;
		displayName = "PTRD-41";
		descriptionShort = "The PTRD-41 Degtyaryov Anti-Tank Rifle Is a Rifle Chambered in 50BMG";
		hiddenSelectionsTextures[] = {"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD41_co.paa","UAVWEAPONS\PTRD-41\PTRD-41\data\Bolt_co.paa"};
	};
};
class cfgSoundsets
{
	class Rifle_Shot_Base_SoundSet;
	class PTRD_41_Shot_SoundSet: Rifle_Shot_Base_SoundSet
	{
		soundShaders[] = {"PTRD_41_closeShot_SoundShader","PTRD_41_midShot_SoundShader","PTRD_41_distShot_SoundShader"};
	};
};
class CfgSoundShaders
{
	class PTRD_41_closeShot_SoundShader
	{
		samples[] = {{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_Shot",1},{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_Shot",1},{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_Shot",1}};
		volume = 0.25;
		range = 50;
		rangeCurve = "closeShotCurve";
	};
	class PTRD_41_midShot_SoundShader
	{
		samples[] = {{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_Shot",1},{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_Shot",1},{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_Shot",1}};
		volume = 0.2;
		range = 600;
		rangeCurve = "midShotCurve";
	};
	class PTRD_41_distShot_SoundShader
	{
		samples[] = {{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_Shot",1},{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_Shot",1},{"UAVWEAPONS\PTRD-41\PTRD-41\data\PTRD_Shot",1}};
		volume = 0.18;
		range = 1200;
		rangeCurve = "farShotCurve";
	};
};
