////////////////////////////////////////////////////////////////////
//DeRap: PTRD-41\config.bin
//Produced from mikero's Dos Tools Dll version 10.21
//https://mikero.bytex.digital/Downloads
//'now' is Wed Nov 04 03:50:04 2026 : 'file' last modified on Sat Oct 24 21:26:39 2026
////////////////////////////////////////////////////////////////////

#define _ARMA_

class CfgPatches
{
	class PTRD
	{
		requiredAddons[] = {"DZ_Data","DZ_Characters_Vests","DZ_Scripts","DZ_Characters"};
		units[] = {};
		weapons[] = {};
	};
};
class CfgMods
{
	class PTRD
	{
		dir = "";
		picture = "";
		action = "";
		hideName = 1;
		hidePicture = 1;
		name = "";
		credits = "UAV7";
		author = "UAV";
		authorID = "0";
		version = "1.0";
		extra = 0;
		type = "mod";
		dependencies[] = {"World"};
		class defs
		{
			class worldScriptModule
			{
				value = "";
				files[] = {"UAVWEAPONS/PTRD-41/PTRD-41/scripts/4_World"};
			};
		};
	};
};
