param(
 [string]$OldPlayerPbo,
 [string]$GamePath = "${env:ProgramFiles(x86)}\Steam\steamapps\common\DayZ",
 [string]$OutputFolder = $PSScriptRoot
)
$ErrorActionPreference = 'Stop'
if (!$OldPlayerPbo) {
 Add-Type -AssemblyName System.Windows.Forms
 $picker = New-Object System.Windows.Forms.OpenFileDialog
 $picker.Title = 'Select the DOWNLOADED DayZ 1.27 anims_anm_player.pbo'
 $picker.Filter = 'Player animation archive (anims_anm_player.pbo)|anims_anm_player.pbo'
 $picker.InitialDirectory = Join-Path $env:USERPROFILE 'Downloads'
 try {
  if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'No 1.27 archive selected. Nothing exported.' }
  $OldPlayerPbo = $picker.FileName
 } finally { $picker.Dispose() }
}
$currentPbo = Join-Path $GamePath 'Addons/anims_anm_player.pbo'
foreach ($path in @($OldPlayerPbo,$currentPbo)) {
 if (!(Test-Path -LiteralPath $path -PathType Leaf)) { throw "Animation archive missing: $path" }
}
if ([IO.Path]::GetFullPath($OldPlayerPbo) -eq [IO.Path]::GetFullPath($currentPbo)) { throw 'The old archive and current archive are the same file. Select the downloaded 1.27 archive.' }
if (!('GRZClipComparePboV1' -as [type])) { Add-Type -Path (Join-Path $PSScriptRoot 'GRZ-ClipComparePbo.cs') }
Add-Type -AssemblyName System.IO.Compression.FileSystem
$wanted = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'CLIPS.json') -Raw | ConvertFrom-Json
if ($wanted.Count -ne 25) { throw "Expected the reviewed 25-clip list; got $($wanted.Count) items. Nothing exported." }
$oldIndex = @{}
$currentIndex = @{}
foreach ($entry in [GRZClipComparePboV1]::Index($OldPlayerPbo)) {
 if ($oldIndex.ContainsKey($entry.Path)) { throw "Duplicate old animation path: $($entry.Path)" }
 $oldIndex[$entry.Path] = $entry
}
foreach ($entry in [GRZClipComparePboV1]::Index($currentPbo)) {
 if ($currentIndex.ContainsKey($entry.Path)) { throw "Duplicate current animation path: $($entry.Path)" }
 $currentIndex[$entry.Path] = $entry
}
foreach ($path in $wanted) {
 if (!$oldIndex.ContainsKey($path)) { throw "Selected clip missing from OLD archive: $path" }
 if (!$currentIndex.ContainsKey($path)) { throw "Selected clip missing from CURRENT archive: $path" }
}
function Get-BytesHash([byte[]]$Data) {
 $digest = [Security.Cryptography.SHA256]::Create()
 try { return [BitConverter]::ToString($digest.ComputeHash($Data)).Replace('-','').ToLowerInvariant() }
 finally { $digest.Dispose() }
}
New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
$token = [guid]::NewGuid().ToString('N')
$stage = Join-Path $OutputFolder ('GRZ-127-export-work-' + $token)
$exportId = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $token.Substring(0,8)
$part = 1
$partBytes = 0
$limit = 24 * 1024 * 1024
$rows = @()
$partFolders = @()
try {
 New-Item -ItemType Directory -Path $stage | Out-Null
 foreach ($path in $wanted) {
  Write-Host "Comparing $path"
  [byte[]]$oldBytes = [GRZClipComparePboV1]::Read($OldPlayerPbo,$oldIndex[$path])
  [byte[]]$currentBytes = [GRZClipComparePboV1]::Read($currentPbo,$currentIndex[$path])
  $oldHash = Get-BytesHash $oldBytes
  $currentHash = Get-BytesHash $currentBytes
  if ($partBytes -gt 0 -and $partBytes + $oldBytes.Length -gt $limit) { $part++; $partBytes = 0 }
  $partFolder = Join-Path $stage ('part-' + $part)
  if ($partFolders -notcontains $partFolder) { $partFolders += $partFolder }
  $relative = $path.Replace('/',[IO.Path]::DirectorySeparatorChar)
  $target = Join-Path (Join-Path $partFolder 'old127') $relative
  New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
  [IO.File]::WriteAllBytes($target,$oldBytes)
  $partBytes += $oldBytes.Length
  $rows += [pscustomobject]@{
   VirtualPath = $path
   OldBytes = $oldBytes.Length
   CurrentBytes = $currentBytes.Length
   OldSHA256 = $oldHash
   CurrentSHA256 = $currentHash
   Identical = ($oldHash -eq $currentHash)
   OldClipZipPart = $part
  }
 }
 $gameVersion = $null
 $gameExe = Join-Path $GamePath 'DayZ_x64.exe'
 if (Test-Path -LiteralPath $gameExe -PathType Leaf) { $gameVersion = [string](Get-Item -LiteralPath $gameExe).VersionInfo.FileVersion }
 $report = [ordered]@{
  Purpose = 'Read-only old/current animation byte comparison; exports only the selected old clips.'
  OldArchiveLabel = 'User-selected downloaded 1.27 archive; version is not independently authenticated by this tool.'
  ExpectedDownloadManifest = '3309608757320055497'
  CurrentGameFileVersion = $gameVersion
  OldArchiveSHA256 = (Get-FileHash -LiteralPath $OldPlayerPbo -Algorithm SHA256).Hash.ToLowerInvariant()
  CurrentArchiveSHA256 = (Get-FileHash -LiteralPath $currentPbo -Algorithm SHA256).Hash.ToLowerInvariant()
  ClipCount = $rows.Count
  IdenticalClips = @($rows | Where-Object { $_.Identical }).Count
  DifferentClips = @($rows | Where-Object { !$_.Identical }).Count
  Clips = $rows
 }
 $number = 0
 foreach ($folder in $partFolders) {
  $number++
  $report | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $folder 'REPORT.json') -Encoding UTF8
  $zip = Join-Path $OutputFolder ('GRZ-127-Clips-' + $exportId + '-part' + $number + '.zip')
  [IO.Compression.ZipFile]::CreateFromDirectory($folder,$zip,[IO.Compression.CompressionLevel]::Optimal,$false)
  if ((Get-Item -LiteralPath $zip).Length -ge 32 * 1024 * 1024) { throw "Export ZIP unexpectedly exceeds 32 MiB: $zip" }
  Write-Host "UPLOAD THIS: $zip"
 }
 Write-Host ("Compared {0} clips: {1} identical, {2} different. Game/server files were only read." -f $report.ClipCount,$report.IdenticalClips,$report.DifferentClips)
 Write-Host 'Upload all GRZ-127-Clips-...-part*.zip files created by this run.'
} finally {
 if (Test-Path -LiteralPath $stage -PathType Container) { Remove-Item -LiteralPath $stage -Recurse -Force }
}
