name = "GRZ Custom Hud";
author = "GRZ";
version = "0.1.11";
overview = "Minimal black health and blood indicators with clean tribal-thorn frames.";
