# GRZ InstaDrop v0.4.3 prone-side rifle ready continuation test

The v0.4.2 post-drop log now shows the throw body active, native side/back aim
angles over 90 degrees and onBack=true. Raise input then becomes true while
script preparation turns off; weapon/body mode follows it out. The native
CanContinueThrowing method rejects raise input. This suggests cancellation of
preparation during aiming is involved, rather than missing animation clips.
Clearance, gear or another condition could also contribute; they are now logged.
The raise cancellation check predates 1.30, so no new-engine bug is established.

## Change

Adds one modded CanContinueThrowing method. Native accepted results are returned
unchanged. After a native rejection, an exception is possible only for a living,
conscious, unrestrained rifle user in the native movement command, already
prone at a native side/back aim angle outside +/-90 degrees, with preparation
active and raise input pressed. No attack, charge, release, standing-from-back,
gear, action, emote or weapon operation is allowed through this exception, and
the native CheckFreeSpace test must pass. It does not synthesize input, force
stances, change angles/positions or toggle throwing mode itself.

Raising/aiming in this narrow prone-side ready case intentionally keeps the
preparation pose. G toggle, inventory and other native cancellation paths
remain; charge/release is not extended by this exception. Test those controls.
Mods adding their own CanContinueThrowing rejections may overlap; compatibility
with every movement/throwing mod is not guaranteed. Known GRZ Movement source
does not override this method. Its animation/speed/camera setup is unchanged.

The animation graph is byte-identical to v0.4.2. No pose, clip, roll route, angle
mapping or timing changes: drop blend 0.22 and roll-to-stand 0.24 remain.

## Install

Close DayZ and stop the server. Extract into a fresh folder and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires DayZ 1.30.164.289 and the existing GRZ Movement local setup. Graphs are
rebuilt from hash-checked current files. Native game assets and user logs are
not redistributed. Backups/rollback remain. Startup should identify
`v0.4.3 graph selected` and prone-side rifle ready continuation.

## Test

G -> wait for lift -> look right -> prone, then hold the pose for one second.
Repeat with the raise/aim input used in the reference and while moving. Check
whether scriptPrepared, weaponPrepared and throwGraph remain active instead
of cancelling. `raised-ready continuation` logs whether the exception passed,
including native clearance, gear/action clear state and angle. If space=false,
that native rejection is preserved. Existing post-drop samples remain enabled.

Check both roll directions and stand, then G cancellation, inventory, normal
weapon raise outside the scoped case, charge/release and weapon switching.
Check first/third person and another client. If a control sticks or the landing
still differs, restore the last working backup and send fresh script/RPT logs
and a short current-build clip. This is a candidate script fix, not a confirmed
reference match. Enforce compilation and native/multiplayer playback are untested.

## Restore

Close both sides and run with a backup known to contain a working build:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL WORKING-BUILD BACKUP FOLDER"
```
