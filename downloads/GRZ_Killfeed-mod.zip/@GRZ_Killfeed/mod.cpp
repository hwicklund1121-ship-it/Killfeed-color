name = "GRZ Killfeed";
author = "GRZ";
version = "0.1.3";
overview = "Player killfeed with Steam-ID controlled name colors and animation.";
