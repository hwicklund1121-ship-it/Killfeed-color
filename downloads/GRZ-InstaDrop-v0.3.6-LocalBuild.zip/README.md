# GRZ InstaDrop v0.3.6 single-direction roll test

Based on v0.3.5. Changes one graph property: the native ProneRollRightLeft
selector's BlendTime goes from 0.3 to 0.0 seconds. The selector now chooses
one native roll direction immediately instead of crossfading opposing clips.
This tests a possible contributor to the sideways leg swing. It does not prove
the cause or guarantee a smooth spin: drop-pose interpolation and foot IK are
unchanged, and entry/exit snapping still needs an in-game comparison.

Retains the native roll/foot clips, trigger conditions, active-roll guards,
opposite-side landing mapping, center-back pose, 0.22-second drop blend and
0.24-second stand blend. Those are blend durations, not measured action times.
No new animations, camera overrides, movement speed changes or keys are added.

## Install

Close DayZ and stop the server, extract to a new folder, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires DayZ 1.30.164.289 and the existing GRZ Movement local setup. Native
graphs are built locally from hash-checked game files; no native graph or
animation payload is distributed. Installer backups/rollback remain included.
Startup should identify `v0.3.6 graph selected` and the selector test.

## Test

Repeat G -> drop -> roll -> stand for each side. Compare feet/leg rotation,
entry snaps and roll-to-standing motion against v0.3.5. Check right-look/left
landing and the reverse. Confirm slower drop and stand timing still feels
correct. Capture a short clip if the legs still swing: that may be the drop
pose blend rather than this native roll selector. Native graph compilation,
loading and visible motion remain unverified here.

## Restore

Close DayZ and stop the server. Use the exact backup path printed by installer:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL BACKUP FOLDER"
```
