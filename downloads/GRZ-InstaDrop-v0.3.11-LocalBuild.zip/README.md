# GRZ InstaDrop v0.3.11 side-landing restore test

Removes the forced back-landing changes. Restores the approved v0.3.6 roll,
stance and gun-lift baseline. The v0.3.7 on-back gun-hold overlay and v0.3.8
forced PoB drop entry are not included. The v0.3.9 roll-route experiment and
v0.3.10 side flip are not included.

The three directional drop-pose rows now contain only their existing left/right
side samples. Neutral look selects the positive-X side sample, and the outer
look angles repeat the corresponding side sample instead of selecting a back
endpoint. AimX/AimY inputs, drop blend 0.22, stand blend 0.24, native roll clips,
roll direction selector and active-roll guards remain from v0.3.6.

Runtime limits: blending between two side poses can still change intermediate
body orientation. Removing the on-back gun-hold overlay may restore the earlier
straight-out rifle pose. This is a side-landing test, not a confirmed recreation
of 1.27 or a guarantee of unchanged foot motion. No native keyframes are edited.

## Install

Close DayZ and stop the server. Extract this ZIP to a fresh folder and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires the existing DayZ 1.30.164.289 / GRZ Movement local setup. Graphs are
built locally from hash-checked game files; no native animation/graph assets
are redistributed. Installer backs up all three PBOs on both sides. Startup
should identify `v0.3.11 graph selected` and the side-pose landing test.

## Check

Test G -> drop looking forward, right and left. Confirm side landing replaces
the reclined back landing, and check camera/body behavior while moving aim
between sides. Then check feet during both rolls and normal mid-roll stand.
Check gun alignment separately, first/third person and from another client.
Send a short current-build clip if a back pose, sideways foot swing or gun
issue remains. Gameplay and native graph compilation/loading are unverified.

## Restore

Close both sides and use the exact backup folder printed by the installer:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL BACKUP FOLDER"
```
