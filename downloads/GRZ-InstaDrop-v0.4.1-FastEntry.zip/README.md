# GRZ InstaDrop v0.4.1 fast-entry restoration / input diagnostics

The user reports v0.4.0 ignores prone during gun lift. That build restored the
native stance-transition state as well as the native pose chain. This test
restores direct Erc/Cro -> Pne entry (0.22 seconds) and a 0.22 native strength
stance blend, while keeping native strength weight 1.0, angle selection and
source clips. It does not revert to fixed side/back pose experiments.

The graph change bypasses the tagged intermediate stance-transition clip.
It cannot prove that an input rejected earlier will now be accepted. To diagnose
that, the script now logs real stance requests, command/stance, preparation and
charge/release flags, exception permission, and native intro/idle/prone-transition
tags through HumanAnimInterface.BindTag/IsTag. These APIs are declared in the
Bohemia public human.c interface. No positions, identifiers or text input are
logged. Existing permissions and native physics/action/water checks are kept.
No persistent stance lock, synthetic keyboard input or forced position is added.

Retains roll guards, native roll clips and the 0.24 roll-to-stand helper blend.
All 25 selected old/current animation clips compared earlier were identical;
1.30 engine/input/transition behavior can still differ from the old reference.

## Install

Close DayZ and stop the server, extract into a new folder, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires the current DayZ 1.30.164.289 / GRZ Movement local setup. Graphs are
built from hash-checked current files. Native assets/old clips/logs are not
redistributed. Installer backup and rollback remain. Startup should identify
`v0.4.1 graph selected` and fast prone entry restored.

## Check

First test G -> WAIT for lift -> prone. Then repeat prone DURING the lift,
while moving, and with the look direction used in the reference. Compare gun
hold, landing, both roll directions and mid-roll standing. Check normal stance
and charge/cancel/release, first/third person and a second client's view.

If prone is still ignored, reproduce once and send the newest script log and
RPT. Look for `v0.4.1 drop-input` plus the existing `stance from=... allowed=...`
trace. Input traces without a stance callback identify a different failure
point from a callback that rejects the exception. These logs do not identify
the cause alone without the actual values from the run.

Source/package checks passed. DayZ graph loading, Enforce compilation, input
acceptance, animation playback and multiplayer behavior have not been tested
here. Keep the last working ZIP and backup for comparison.

## Restore

Close both sides and run with a backup known to contain a working build:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL WORKING-BUILD BACKUP FOLDER"
```
