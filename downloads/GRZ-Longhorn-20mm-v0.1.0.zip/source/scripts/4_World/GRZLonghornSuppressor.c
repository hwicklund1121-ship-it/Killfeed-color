// The extra vanilla mount is permitted only on Longhorns. Other weapons must
// expose one of this suppressor's original custom slots, preserving compatibility.
modded class ItemSuppressor
{
    override bool CanPutAsAttachment(EntityAI parent)
    {
        if (!super.CanPutAsAttachment(parent)) return false;
        if (!IsKindOf("UAV_M82A2_Sup")) return true;
        if (!parent) return false;
        if (parent.IsKindOf("LongHorn_Base")) return true;
        array<string> slots = new array<string>;
        GetGame().ConfigGetTextArray("CfgWeapons " + parent.GetType() + " attachments", slots);
        return slots.Find("UAV_M82A2_Suppressor") >= 0;
    }
};
