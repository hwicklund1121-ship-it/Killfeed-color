class CfgPatches
{
    class GRZ_Longhorn20mm
    {
        units[] = {};
        weapons[] = {};
        requiredVersion = 0.1;
        requiredAddons[] = {"DZ_Pistols_Encore", "UAV", "UAV_M82A2_Suppressor"};
    };
};
class CfgMods
{
    class GRZ_Longhorn20mm
    {
        dir = "GRZ_Longhorn20mm";
        name = "GRZ Longhorn 20mm";
        type = "mod";
        dependencies[] = {"World"};
        class defs
        {
            class worldScriptModule
            {
                value = "";
                files[] = {"GRZ_Longhorn20mm/scripts/4_World"};
            };
        };
    };
};
class CfgWeapons
{
    class Pistol_Base;
    class LongHorn_Base: Pistol_Base
    {
        chamberableFrom[] = {"UAV_Ammo_VULCAN"};
        // Match the supplied M99's barrel protection for this high-wear round.
        barrelArmor = 3000;
        class Single;
    };
    class LongHorn: LongHorn_Base
    {
        class Single: Single
        {
            soundSetShotExt[] =
            {
                {"GRZ_Longhorn20mm_Suppressed_SoundSet"},
                {"GRZ_Longhorn20mm_Suppressed_SoundSet"}
            };
        };
    };
};
class CfgVehicles
{
    class M82A2_Suppressor_Base;
    class UAV_M82A2_Sup: M82A2_Suppressor_Base
    {
        // Reuse the existing vanilla Longhorn muzzle proxy; retain native slot.
        inventorySlot[] += {"suppressorImpro"};
    };
};
class CfgSoundShaders
{
    class GRZ_Longhorn20mm_Sup_Close_Shader
    {
        samples[] = {{"GRZ_Longhorn20mm/sounds/ax50_sup", 1}};
        volume = 1;
        range = 150;
        rangeCurve[] = {{0,1},{50,0.8},{150,0}};
    };
    class GRZ_Longhorn20mm_Sup_Mid_Shader
    {
        samples[] = {{"GRZ_Longhorn20mm/sounds/ax50_sup_mid", 1}};
        volume = 1;
        range = 600;
        rangeCurve[] = {{0,0},{50,0},{150,1},{350,0.6},{600,0}};
    };
    class GRZ_Longhorn20mm_Sup_Far_Shader
    {
        samples[] = {{"GRZ_Longhorn20mm/sounds/ax50_sup_far", 1}};
        volume = 1;
        range = 1500;
        rangeCurve[] = {{0,0},{150,0},{450,1},{900,0.5},{1500,0}};
    };
};
class CfgSoundSets
{
    class Rifle_Shot_Base_SoundSet;
    class GRZ_Longhorn20mm_Suppressed_SoundSet: Rifle_Shot_Base_SoundSet
    {
        soundShaders[] =
        {
            "GRZ_Longhorn20mm_Sup_Close_Shader",
            "GRZ_Longhorn20mm_Sup_Mid_Shader",
            "GRZ_Longhorn20mm_Sup_Far_Shader"
        };
        volumeFactor = 1;
    };
};
