GRZ Longhorn 20mm v0.1.0 - TEST BUILD

Changes the existing LongHorn (same spawn classname):
- Chambers UAV_Ammo_VULCAN only; keeps one-shot capacity and vanilla visuals.
- Accepts UAV_M82A2_Sup through the existing suppressorImpro muzzle mount.
  The suppressor retains its original UAV_M82A2_Suppressor slot on other weapons.
  A scoped script prevents the extra mount from enabling it on unrelated guns.
- Uses the three supplied AX50 sounds for suppressed close/mid/far shots.
  Samples converted from stereo to mono 44.1 kHz Vorbis for positional audio.
  Unsuppressed firing sounds remain native. Bottle suppressors also use the
  new suppressed Longhorn sound. The same mount prevents stacking suppressors.
- Sets LongHorn_Base barrelArmor=3000, matching the supplied M99, to accommodate
  the Vulcan round's damageBarrel=800. Projectile damage and ammo are untouched.

INSTALL
Close DayZ and stop the server. Copy @GRZ_Longhorn20mm beside your other mods
on BOTH client and server. Add @GRZ_Longhorn20mm to the -mod list after UAV's
weapon/ammo/suppressor mod. Alternatively, copy GRZ_Longhorn20mm.pbo into the
Addons directory of an existing LOCAL mod loaded on BOTH client and server.
Use one installation method only. Retain the original UAV mod and its assets.
This PBO does not contain UAV's models, textures, ammo config or M99 config.

This PBO is unsigned and contains config.cpp source rather than binarized config.
Sign with your normal server key before using a server that requires signatures.
Do not disable signature verification as a workaround.

SPAWN / LOADOUT CLASSNAMES
LongHorn
UAV_M99_Black
UAV_Ammo_VULCAN
UAV_M82A2_Sup

Both guns belong under your loadout's existing 20mm category. The loadout file
has NOT been edited: it has not been provided and its schema is unknown.
M99 already accepts the Vulcan round; this patch does not change the M99.

VALIDATION / LIMITS
PBO payload round-trip, footer SHA1, ZIP CRC, sound decoding and config references
checked. No DayZ config compilation or in-game execution was available.
Test loading, chambering/firing, suppressor attachment/removal and visual
alignment, suppressed sound at multiple distances, durability, and another
client's view. UAV-specific script restrictions may require an additional patch.
The M82 suppressor is larger than the original bottle; exact fit is unverified.
To remove, stop both sides and remove this PBO/mod from both and restart.

Editable source/config.cpp and the exact packaged scripts/sounds are included.
