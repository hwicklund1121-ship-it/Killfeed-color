class UAV_Snipex_M100_Base : BoltActionRifle_InnerMagazine_Base
{
	override RecoilBase SpawnRecoilObject()
	{
		return new SSG82Recoil(this);
	}	
};