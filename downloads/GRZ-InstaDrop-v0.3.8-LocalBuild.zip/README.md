# GRZ InstaDrop v0.3.8 direct on-back entry test

Goal: move the current native prototype toward the supplied DayZ 1.27 reference
for gun hold, side/back landing and continuous leg rotation. The two supplied
videos are references, not verified recordings of this build. No exact 1.27
recreation or cause of a current-build visual defect is established by them.

Relative to v0.3.7, changes only two transition destinations in the prepared
throw stance machine: Erc -> PoB and Cro -> PoB, rather than Erc/Cro -> Pne.
PoB already uses the same directional/gun-hold node as Pne but carries the native
TagProneBack. This aligns the entry state with the intended side/back pose.

Keeps v0.3.7's native on-back gun-aim layer, side table, source clips, native
roll selector, roll guards, drop blend 0.22 and stand blend 0.24 unchanged.
Native tag evaluation may affect weapon IK or roll selection: unchanged nodes
and clips do not guarantee identical foot/body playback. Both gun alignment
and preservation of v0.3.6's approved leg motion require an in-game check.
This does not restore the old DayZ graph, redistribute old clips, or fabricate
new spin keyframes from the reference video. No new keys or speed tuning.

## Install

Keep the working v0.3.6 ZIP. Close DayZ and stop the server. Extract to a new
folder, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires the existing DayZ 1.30.164.289 / GRZ Movement local setup. The graph is
built locally from hash-checked game files. Native graph/animation/ASI/AST
payloads are not included. Installer backs up all three PBOs on both sides.
Startup should identify `v0.3.8 graph selected` and direct on-back entry test.

## Check against the reference

Record the same G -> drop -> roll -> stand sequence looking forward, right
and left. Check the gun remains held close during the initial landing, that
look-right lands left, and that legs rotate continuously rather than sweeping
sideways. Check first/third person and another client. Compare with approved
v0.3.6 feet and current v0.3.7 gun hold. Also test normal stance input and
charge/cancel/release. Source/package checks cannot verify native graph loading,
IK, 1.27-like motion or multiplayer playback. If it changes the approved feet,
restore v0.3.6 and supply a clip from the actual current build for comparison.

## Restore

Close both sides and use the exact backup folder printed by the installer:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL BACKUP FOLDER"
```
