////////////////////////////////////////////////////////////////////
//DeRap: CS5\CS5\config.bin
//Produced from mikero's Dos Tools Dll version 10.21
//https://mikero.bytex.digital/Downloads
//'now' is Wed Nov 04 03:49:59 2026 : 'file' last modified on Sat Oct 24 21:26:42 2026
////////////////////////////////////////////////////////////////////

#define _ARMA_

class CfgPatches
{
	class CS5_Base
	{
		units[] = {};
		weapons[] = {"CS5_Base","UAV_CS5_BLACK"};
		requiredVersion = 0.1;
		requiredAddons[] = {"DZ_Data","DZ_Weapons_Firearms","DZ_Weapons_Ammunition","DZ_Weapons_Magazines"};
		magazines[] = {"CS5_Magazine_10RND"};
		ammo[] = {"UAV_Bullet_50CAL"};
	};
};
class Mode_Safe;
class Mode_SemiAuto;
class Mode_Single;
class Mode_Burst;
class Mode_FullAuto;
class OpticsInfoRifle;
class cfgWeapons
{
	class BoltActionRifle_Base;
	class CS5_Base: BoltActionRifle_Base
	{
		scope = 0;
		descriptionShort = "US NATO sniper rifle. The gun was specifically designed as a powerful, compact, low-noise, high-precision weapon for covert and camouflaged use by army and law enforcement forces at close range, most often in urban environments. Fed from detachable magazines with .50 CAL rounds. ported by uavmods.";
		model = "UAVWEAPONS\CS5\CS5\data\cs5.p3d";
		weight = 13500;
		WeaponLength = 1;
		hiddenSelections[] = {"color","color2","color3","color4"};
		itemSize[] = {10,2};
		dexterity = 1.8;
		absorbency = 0.1;
		repairableWithKits[] = {5,1};
		repairCosts[] = {30,25};
		discreteDistance[] = {100,200,300,400,500,600,700,800,900,1000,1100};
		discreteDistanceInitIndex = 0;
		modelOptics = "-";
		distanceZoomMin = 100;
		distanceZoomMax = 100;
		PPDOFProperties[] = {1,0.5,50,180,4,10};
		optics = 1;
		opticsFlare = 0;
		value = 0;
		chamberedRound = "";
		chamberSize = 1;
		simpleHiddenSelections[] = {"hide_barrel"};
		attachments[] = {"weaponOptics","weaponOpticsHunting","weaponWrap"};
		canReceiveHuntingOptic = 1;
		chamberableFrom[] = {"UAV_Ammo_50CAL"};
		magazines[] = {"CS5_Magazine_10RND"};
		magazineSwitchTime = 0.25;
		barrelArmor = 3000;
		ejectType = 1;
		recoilModifier[] = {1,3,2};
		reloadAction = "Reloadcz527";
		modes[] = {"Single"};
		class Single: Mode_SemiAuto
		{
			soundSetShot[] = {"ots14_silencerHomeMade_SoundSet","ots14_silencerHomeMadeTail_SoundSet","ots14_silencerInteriorHomeMadeTail_SoundSet"};
			reloadTime = 0.6;
			recoil = "recoil_cz527";
			recoilProne = "recoil_cz527_prone";
			dispersion = 0.0007;
			magazineSlot = "magazine";
		};
		class Particles
		{
			class OnFire
			{
				class SmokeCloud
				{
					overrideParticle = "weapon_shot_winded_smoke";
				};
				class MuzzleFlash
				{
					overrideParticle = "weapon_shot_fnx_02";
					ignoreIfSuppressed = 1;
					illuminateWorld = 1;
					positionOffset[] = {-0.05,0,0};
				};
			};
			class OnOverheating
			{
				shotsToStartOverheating = 1;
				maxOverheatingValue = 4;
				overheatingDecayInterval = 3;
				class BarrelSmoke
				{
					overrideParticle = "smoking_barrel_small";
				};
			};
			class OnBulletCasingEject
			{
				class ChamberSmokeRaise
				{
					overrideParticle = "weapon_shot_chamber_smoke_raise";
					overridePoint = "Nabojnicestart";
				};
			};
		};
		class OpticsInfo: OpticsInfoRifle
		{
			memoryPointCamera = "eye";
			modelOptics = "-";
			distanceZoomMin = 100;
			distanceZoomMax = 100;
			discreteDistance[] = {100,200,300,400,500,600,700,800,900,1000};
			discreteDistanceInitIndex = 0;
		};
		class AnimEvents
		{
			class SoundWeapon
			{
				class walkErc_L
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 1;
				};
				class walkErc_R
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_R_SoundSet";
					id = 2;
				};
				class runErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 3;
				};
				class runErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_R_SoundSet";
					id = 4;
				};
				class sprintErc_L
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 5;
				};
				class sprintErc_R
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 6;
				};
				class walkCro_L
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 21;
				};
				class walkCro_R
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 22;
				};
				class runCro_L
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 23;
				};
				class runCro_R
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 24;
				};
				class walkProne_L
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 31;
				};
				class walkProne_R
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 32;
				};
				class runProne_L
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 33;
				};
				class runProne_R
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 34;
				};
				class jumpErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 35;
				};
				class jumpErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 36;
				};
				class landFootErc_L
				{
					soundSet = "Weapon_Movement_HRifle_landFootErc_SoundSet";
					id = 37;
				};
				class landFootErc_R
				{
					soundSet = "Weapon_Movement_HRifle_landFootErc_SoundSet";
					id = 38;
				};
				class walkRasErc_L
				{
					soundSet = "Weapon_Movement_HRifle_walkRasErc_SoundSet";
					id = 51;
				};
				class walkRasErc_R
				{
					soundSet = "Weapon_Movement_HRifle_walkRasErc_SoundSet";
					id = 52;
				};
				class runRasErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runRasErc_SoundSet";
					id = 53;
				};
				class runRasErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runRasErc_SoundSet";
					id = 54;
				};
				class HandStep_L
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 61;
				};
				class HandStep_R
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 62;
				};
				class HandStep_Hard_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 63;
				};
				class HandStep_Hard_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 64;
				};
				class landFeetErc
				{
					soundSet = "Weapon_Movement_HRifle_landFeetErc_SoundSet";
					id = 100;
				};
				class Weapon_Movement_HRifle_Walk
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 101;
				};
				class Weapon_Movement_HRifle_Run
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 102;
				};
				class Weapon_Movement_HRifle_Sprint
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 103;
				};
				class Weapon_Movement_HRifle_Land
				{
					soundSet = "Weapon_Movement_HRifle_landFeetErc_SoundSet";
					id = 104;
				};
				class Char_Gestures_Hand_Grab_Rifle
				{
					soundSet = "Char_Gestures_Hand_Grab_FabricRifle_SoundSet";
					id = 892;
				};
			};
		};
		class DamageSystem
		{
			class GlobalHealth
			{
				class Health
				{
					hitpoints = 10000;
					healthLevels[] = {{1,{"UAVWEAPONS\CS5\CS5\data\cs5_receiver.rvmat","UAVWEAPONS\CS5\CS5\data\cs5_stock.rvmat","UAVWEAPONS\CS5\CS5\data\cs5_barrel.rvmat","UAVWEAPONS\CS5\CS5\data\suppressor.rvmat"}},{0.7,{"UAVWEAPONS\CS5\CS5\data\cs5_receiver.rvmat","UAVWEAPONS\CS5\CS5\data\cs5_stock.rvmat","UAVWEAPONS\CS5\CS5\data\cs5_barrel.rvmat","UAVWEAPONS\CS5\CS5\data\suppressor.rvmat"}},{0.5,{""}},{0.3,{""}},{0,{""}}};
				};
			};
		};
	};
	class UAV_CS5_BLACK: CS5_Base
	{
		scope = 2;
		displayName = "McMillan CS5";
		hiddenSelectionsTextures[] = {"UAVWEAPONS\CS5\CS5\data\cs5_receiver_co.paa","UAVWEAPONS\CS5\CS5\data\cs5_stock_co.paa","UAVWEAPONS\CS5\CS5\data\cs5_barrel_co.paa","UAVWEAPONS\CS5\CS5\data\suppressor_co.paa"};
		hiddenSelectionsMaterials[] = {"UAVWEAPONS\CS5\CS5\data\cs5_receiver.rvmat","UAVWEAPONS\CS5\CS5\data\cs5_stock.rvmat","UAVWEAPONS\CS5\CS5\data\cs5_barrel.rvmat","UAVWEAPONS\CS5\CS5\data\suppressor.rvmat"};
	};
};
class cfgMagazines
{
	class Magazine_Base;
	class CS5_Magazine_10RND: Magazine_Base
	{
		scope = 2;
		displayName = "10rd McMillan CS5 Mag";
		descriptionShort = "Detachable box magazine for the McMillan CS5 sniper rifle. Holds up to 10 rounds of .50 CAL";
		model = "UAVWEAPONS\CS5\CS5\data\cs5_mag.p3d";
		weight = 100;
		itemSize[] = {1,2};
		count = 10;
		ammo = "UAV_Bullet_50CAL";
		ammoItems[] = {"UAV_Ammo_50CAL"};
		tracersEvery = 0;
		hiddenSelections[] = {"magazine"};
		hiddenSelectionsTextures[] = {"UAVWEAPONS\CS5\CS5\data\cs5_mag_co.paa"};
		class DamageSystem
		{
			class GlobalHealth
			{
				class Health
				{
					hitpoints = 10000;
					healthLevels[] = {{1.0,{"UAVWEAPONS\CS5\CS5\data\cs5_mag.rvmat"}},{0.7,{"UAVWEAPONS\CS5\CS5\data\cs5_mag.rvmat"}},{0.5,{""}},{0.3,{""}},{0.0,{""}}};
				};
			};
		};
		class AnimEvents
		{
			class SoundWeapon
			{
				class MagRifle_fill_in
				{
					soundSet = "MagRifle_fill_in_SoundSet";
					id = 1;
				};
				class MagRifle_fill_loop
				{
					soundSet = "MagRifle_fill_loop_SoundSet";
					id = 2;
				};
				class MagRifle_fill_out
				{
					soundSet = "MagRifle_fill_out_SoundSet";
					id = 3;
				};
				class MagRifle_empty_in
				{
					soundSet = "MagRifle_empty_in_SoundSet";
					id = 4;
				};
				class MagRifle_empty_loop
				{
					soundSet = "MagRifle_empty_loop_SoundSet";
					id = 5;
				};
				class MagRifle_empty_out
				{
					soundSet = "MagRifle_empty_out_SoundSet";
					id = 6;
				};
				class MagPistol_fill_in
				{
					soundSet = "MagPistol_fill_in_SoundSet";
					id = 7;
				};
				class MagPistol_fill_loop
				{
					soundSet = "MagPistol_fill_loop_SoundSet";
					id = 8;
				};
				class MagPistol_fill_out
				{
					soundSet = "MagPistol_fill_out_SoundSet";
					id = 9;
				};
				class MagPistol_empty_in
				{
					soundSet = "MagPistol_empty_in_SoundSet";
					id = 10;
				};
				class MagPistol_empty_loop
				{
					soundSet = "MagPistol_empty_loop_SoundSet";
					id = 11;
				};
				class MagPistol_empty_out
				{
					soundSet = "MagPistol_empty_out_SoundSet";
					id = 12;
				};
			};
		};
	};
};
class CfgNonAIVehicles
{
	class ProxyAttachment;
	class Proxycs5_mag: ProxyAttachment
	{
		scope = 0;
		inventorySlot = "magazine";
		model = "UAVWEAPONS\CS5\CS5\data\cs5_mag.p3d";
	};
};
