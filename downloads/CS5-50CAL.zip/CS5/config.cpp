////////////////////////////////////////////////////////////////////
//DeRap: CS5\config.bin
//Produced from mikero's Dos Tools Dll version 10.21
//https://mikero.bytex.digital/Downloads
//'now' is Wed Nov 04 03:49:59 2026 : 'file' last modified on Sat Oct 24 21:26:42 2026
////////////////////////////////////////////////////////////////////

#define _ARMA_

class CfgPatches
{
	class CS5
	{
		requiredAddons[] = {"DZ_Data","DZ_Characters_Vests","DZ_Scripts","DZ_Characters"};
		units[] = {};
		weapons[] = {};
	};
};
class CfgMods
{
	class CS5
	{
		dir = "CS5";
		picture = "";
		action = "";
		hideName = 1;
		hidePicture = 1;
		name = "CS5";
		credits = "UAV7";
		author = "UAV";
		authorID = "0";
		version = "1.0";
		extra = 0;
		type = "mod";
		dependencies[] = {"World"};
		class defs
		{
			class worldScriptModule
			{
				value = "";
				files[] = {"UAVWEAPONS/CS5/Scripts/4_World"};
			};
		};
	};
};
