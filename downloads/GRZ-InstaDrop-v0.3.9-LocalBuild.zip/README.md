# GRZ InstaDrop v0.3.9 restore roll-spin route test

Based on v0.3.8, whose landing/gun behavior the user approved. The foot spin
was reported missing during the roll after landing. This test changes one
transition destination: gun-lift Throwing -> PneOnBackRoll now goes to
ProneRoll, like the existing front gun-lift roll route. Both routes therefore
select the original ProneRollSTM with native front-prone left/right roll clips.
This tests whether the new on-back landing state caused a different roll clip
branch to be selected. No source clip is edited and no new animation is made.

Retains the v0.3.8 direct on-back landing, native gun-hold overlay, side mapping,
0.22-second drop blend, 0.24-second stand blend, 0.12-second minimum roll segment,
active-roll guards and normal direction inputs. Ordinary rolls from the native
PneOnBack state remain unchanged; this edit is limited to the Throwing route.

Runtime validation remains required. Switching from an on-back landing to the
front-roll clip branch may change roll-entry continuity or gun pose during the
roll. Source checks do not prove identical v0.3.6 spin or a 1.27 recreation.

## Install

Close DayZ and stop the server. Keep the working v0.3.8 ZIP, extract this test
to a fresh folder, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires DayZ 1.30.164.289 and the existing GRZ Movement local setup. Native
graphs are built locally from hash-checked game files and are not redistributed.
The installer backs up all three PBOs on both sides. Startup should identify
`v0.3.9 graph selected` and the original ProneRoll spin branch.

## Check

Repeat G -> drop -> roll -> stand looking forward/right/left. Confirm the
approved v0.3.8 landing and initial gun hold remain, then check the restored
spin during both roll directions, entry/exit snaps, and mid-roll standing.
Check first/third person, another client's view and ordinary non-gun-lift rolls.
Send a short clip from this actual build if the feet or gun still differ.
No in-game graph loading or multiplayer playback has been verified here.

## Restore

Close both sides and use the exact backup folder printed by the installer:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL BACKUP FOLDER"
```
