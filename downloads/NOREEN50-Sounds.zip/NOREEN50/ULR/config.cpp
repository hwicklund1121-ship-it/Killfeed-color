////////////////////////////////////////////////////////////////////
//DeRap: NOREEN50\ULR\config.bin
//Produced from mikero's Dos Tools Dll version 10.21
//https://mikero.bytex.digital/Downloads
//'now' is Wed Nov 04 03:50:03 2026 : 'file' last modified on Sat Oct 24 21:26:40 2026
////////////////////////////////////////////////////////////////////

#define _ARMA_

class CfgPatches
{
	class UAV_Noreen
	{
		units[] = {};
		weapons[] = {"UAV_Noreen"};
		requiredVersion = 0.1;
		requiredAddons[] = {"DZ_Data","DZ_Weapons_Firearms","DZ_Weapons_Ammunition","DZ_Weapons_Magazines"};
		magazines[] = {};
		ammo[] = {};
	};
};
class Mode_Safe;
class Mode_SemiAuto;
class Mode_Burst;
class Mode_FullAuto;
class OpticsInfoRifle;
class cfgWeapons
{
	class BoltActionRifle_InnerMagazine_Base;
	class UAV_Noreen_Base: BoltActionRifle_InnerMagazine_Base
	{
		scope = 0;
		descriptionShort = "This single shot bolt action was designed with simplicity in mind. The single shot shell holder bolt allows for easy and quick reload, and maintains the simplistic nature of the rifle. The ULR was designed to do one thing; fire large caliber rounds further than most people are capable of.";
		model = "UAVWEAPONS\NOREEN50\ULR\data\Noreen.p3d";
		weight = 13500;
		WeaponLength = 1;
		DisplayMagazine = 0;
		itemSize[] = {10,2};
		dexterity = 1.8;
		absorbency = 0.1;
		repairableWithKits[] = {5,1};
		repairCosts[] = {30,25};
		discreteDistance[] = {100,200,300,400,500,600,700,800,900,1000,1100};
		discreteDistanceInitIndex = 0;
		modelOptics = "-";
		distanceZoomMin = 100;
		distanceZoomMax = 100;
		PPDOFProperties[] = {1,0.5,50,180,4,10};
		chamberedRound = "";
		chamberSize = 1;
		simpleHiddenSelections[] = {};
		attachments[] = {"weaponOpticsHunting","weaponWrap"};
		canReceiveHuntingOptic = 1;
		chamberableFrom[] = {"UAV_Ammo_VULCAN"};
		magazineSwitchTime = 0.25;
		barrelArmor = 3000;
		ejectType = 1;
		recoilModifier[] = {1.5,1.5,2};
		reloadAction = "ReloadSVD";
		modes[] = {"SemiAuto"};
		class SemiAuto: Mode_SemiAuto
		{
			soundSetShot[] = {"Noreen_Shot_SoundSet","Noreen_Shot_SoundSet","Noreen_Shot_SoundSet"};
			reloadTime = 0.425;
			recoil = "recoil_AKM";
			recoilProne = "recoil_AKM_prone";
			dispersion = 0.00075;
			magazineSlot = "magazine";
		};
		class Particles
		{
			class OnFire
			{
				class MuzzleFlash{};
				class SmokeCloud1
				{
					overrideParticle = "weapon_shot_winded_smoke";
				};
				class ChamberFlash
				{
					overridePoint = "Usti hlavne";
					illuminateWorld = 1;
					overrideParticle = "weapon_shot_izh18_01";
				};
				class MuzzleFlash2
				{
					overrideParticle = "weapon_shot_m4a1_01";
					ignoreIfSuppressed = 1;
					illuminateWorld = 1;
				};
				class MuzzleFlashStar
				{
					overrideParticle = "weapon_shot_Flame_3D_4star";
					overridePoint = "usti hlavne";
				};
				class GasPistonBurstR
				{
					overrideParticle = "weapon_shot_chamber_smoke";
					overridePoint = "GasPiston";
					overrideDirectionVector[] = {0,0,0};
				};
				class GasPistonBurstL
				{
					overrideParticle = "weapon_shot_chamber_smoke";
					overridePoint = "GasPiston";
					overrideDirectionVector[] = {180,0,0};
				};
				class GasPistonSmokeRaiseR
				{
					overrideParticle = "weapon_shot_chamber_smoke_raise";
					overridePoint = "GasPiston";
					overrideDirectionVector[] = {0,0,0};
				};
				class GasPistonSmokeRaiseL
				{
					overrideParticle = "weapon_shot_chamber_smoke_raise";
					overridePoint = "GasPiston";
					overrideDirectionVector[] = {180,0,0};
				};
			};
			class OnOverheating
			{
				shotsToStartOverheating = 3;
				maxOverheatingValue = 30;
				overheatingDecayInterval = 2;
				class SmokingBarrelBase
				{
					positionOffset[] = {0.1,0,0};
					onlyWithinRainLimits[] = {0,0.2};
				};
				class SmokingBarrel1: SmokingBarrelBase
				{
					overridePoint = "GasPiston";
					positionOffset[] = {0.05,-0.02,0};
					overrideParticle = "smoking_barrel_small";
					onlyWithinOverheatLimits[] = {0,0.2};
				};
				class SmokingBarrelHot1: SmokingBarrelBase
				{
					overridePoint = "GasPiston";
					positionOffset[] = {0.12,-0.02,0};
					overrideParticle = "smoking_barrel";
					onlyWithinOverheatLimits[] = {0.2,0.6};
				};
				class SmokingBarrelHot3: SmokingBarrelBase
				{
					overridePoint = "GasPiston";
					positionOffset[] = {0.21,-0.02,0};
					overrideParticle = "smoking_barrel_heavy";
					onlyWithinOverheatLimits[] = {0.6,1};
				};
				class Steam
				{
					overrideParticle = "smoking_barrel_steam_small";
					positionOffset[] = {0.4,0.02,0};
					onlyWithinOverheatLimits[] = {0,0.5};
					onlyWithinRainLimits[] = {0.2,1};
				};
				class Steam2
				{
					overrideParticle = "smoking_barrel_steam";
					positionOffset[] = {0.45,0.02,0};
					onlyWithinOverheatLimits[] = {0.5,1};
					onlyWithinRainLimits[] = {0.2,1};
				};
				class ChamberSmokeRaise
				{
					overrideParticle = "smoking_barrel_small";
					overridePoint = "Nabojnicestart";
					onlyWithinOverheatLimits[] = {0.5,1};
				};
			};
		};
		class AnimEvents
		{
			class SoundWeapon
			{
				class walkErc_L
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 1;
				};
				class walkErc_R
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_R_SoundSet";
					id = 2;
				};
				class runErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 3;
				};
				class runErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_R_SoundSet";
					id = 4;
				};
				class sprintErc_L
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 5;
				};
				class sprintErc_R
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 6;
				};
				class walkCro_L
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 21;
				};
				class walkCro_R
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 22;
				};
				class runCro_L
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 23;
				};
				class runCro_R
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 24;
				};
				class walkProne_L
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 31;
				};
				class walkProne_R
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 32;
				};
				class runProne_L
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 33;
				};
				class runProne_R
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 34;
				};
				class jumpErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 35;
				};
				class jumpErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 36;
				};
				class landFootErc_L
				{
					soundSet = "Weapon_Movement_HRifle_landFootErc_SoundSet";
					id = 37;
				};
				class landFootErc_R
				{
					soundSet = "Weapon_Movement_HRifle_landFootErc_SoundSet";
					id = 38;
				};
				class walkRasErc_L
				{
					soundSet = "Weapon_Movement_HRifle_walkRasErc_SoundSet";
					id = 51;
				};
				class walkRasErc_R
				{
					soundSet = "Weapon_Movement_HRifle_walkRasErc_SoundSet";
					id = 52;
				};
				class runRasErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runRasErc_SoundSet";
					id = 53;
				};
				class runRasErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runRasErc_SoundSet";
					id = 54;
				};
				class HandStep_L
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 61;
				};
				class HandStep_R
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 62;
				};
				class HandStep_Hard_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 63;
				};
				class HandStep_Hard_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 64;
				};
				class landFeetErc
				{
					soundSet = "Weapon_Movement_HRifle_landFeetErc_SoundSet";
					id = 100;
				};
				class Weapon_Movement_HRifle_Walk
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 101;
				};
				class Weapon_Movement_HRifle_Run
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 102;
				};
				class Weapon_Movement_HRifle_Sprint
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 103;
				};
				class Weapon_Movement_HRifle_Land
				{
					soundSet = "Weapon_Movement_HRifle_landFeetErc_SoundSet";
					id = 104;
				};
				class Char_Gestures_Hand_Grab_Rifle
				{
					soundSet = "Char_Gestures_Hand_Grab_FabricRifle_SoundSet";
					id = 892;
				};
			};
		};
		class DamageSystem
		{
			class GlobalHealth
			{
				class Health
				{
					hitpoints = 5000;
					healthLevels[] = {{1.01,{"UAVWEAPONS\NOREEN50\ULR\data\Base.rvmat"}},{0.7,{"UAVWEAPONS\NOREEN50\ULR\data\Base.rvmat"}},{0.5,{}},{0.3,{}},{0.01,{}}};
				};
			};
		};
	};
	class UAV_Noreen: UAV_Noreen_Base
	{
		scope = 2;
		displayName = "NOREEN FIREARMS ULR";
		hiddenSelections[] = {"camo"};
		hiddenSelectionsMaterials[] = {"UAVWEAPONS\NOREEN50\ULR\data\Base.rvmat"};
		hiddenSelectionsTextures[] = {"UAVWEAPONS\NOREEN50\ULR\data\Base_co.paa"};
	};
};
class cfgSoundsets
{
	class Rifle_Shot_Base_SoundSet;
	class Noreen_Shot_SoundSet: Rifle_Shot_Base_SoundSet
	{
		soundShaders[] = {"Noreen_Shot_closeShot_SoundShader","Noreen_Shot_midShot_SoundShader","Noreen_Shot_distShot_SoundShader"};
	};
};
class CfgSoundShaders
{
	class Noreen_Shot_closeShot_SoundShader
	{
		samples[] = {{"UAVWEAPONS\NOREEN50\ULR\data\NOREEN50_Shot",1},{"UAVWEAPONS\NOREEN50\ULR\data\NOREEN50_Shot",1},{"UAVWEAPONS\NOREEN50\ULR\data\NOREEN50_Shot",1}};
		volume = 0.25;
		range = 200;
		rangeCurve = "closeShotCurve";
	};
	class Noreen_Shot_midShot_SoundShader
	{
		samples[] = {{"UAVWEAPONS\NOREEN50\ULR\data\NOREEN50_Shot",1},{"UAVWEAPONS\NOREEN50\ULR\data\NOREEN50_Shot",1},{"UAVWEAPONS\NOREEN50\ULR\data\NOREEN50_Shot",1}};
		volume = 0.2;
		range = 600;
		rangeCurve = "midShotCurve";
	};
	class Noreen_Shot_distShot_SoundShader
	{
		samples[] = {{"UAVWEAPONS\NOREEN50\ULR\data\NOREEN50_Shot",1},{"UAVWEAPONS\NOREEN50\ULR\data\NOREEN50_Shot",1},{"UAVWEAPONS\NOREEN50\ULR\data\NOREEN50_Shot",1}};
		volume = 0.18;
		range = 1200;
		rangeCurve = "farShotCurve";
	};
};
