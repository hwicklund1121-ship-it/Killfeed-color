////////////////////////////////////////////////////////////////////
//DeRap: NOREEN50\config.bin
//Produced from mikero's Dos Tools Dll version 10.21
//https://mikero.bytex.digital/Downloads
//'now' is Wed Nov 04 03:50:03 2026 : 'file' last modified on Sat Oct 24 21:26:40 2026
////////////////////////////////////////////////////////////////////

#define _ARMA_

class CfgPatches
{
	class NOREEN50
	{
		requiredAddons[] = {"DZ_Data","DZ_Characters_Vests","DZ_Scripts","DZ_Characters"};
		units[] = {};
		weapons[] = {};
	};
};
class CfgMods
{
	class NOREEN50
	{
		dir = "NOREEN50";
		picture = "";
		action = "";
		hideName = 1;
		hidePicture = 1;
		name = "NOREEN50";
		credits = "UAV7";
		author = "UAV";
		authorID = "0";
		version = "1.0";
		extra = 0;
		type = "mod";
		dependencies[] = {"World"};
		class defs
		{
			class worldScriptModule
			{
				value = "";
				files[] = {"UAVWEAPONS/NOREEN50/Scripts/4_World"};
			};
		};
	};
};
