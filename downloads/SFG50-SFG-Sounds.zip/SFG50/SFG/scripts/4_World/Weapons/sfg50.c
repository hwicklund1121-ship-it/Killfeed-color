class sfg50_Base : BoltActionRifle_InnerMagazine_Base
{
	override RecoilBase SpawnRecoilObject()
	{
		return new Winchester70Recoil(this);
	}

    protected int m_GRZSFGSuppressorAttempts;

    override void EEInit()
    {
        super.EEInit();
        GRZQueuePermanentSuppressor();
    }

    override void EEOnAfterLoad()
    {
        super.EEOnAfterLoad();
        GRZQueuePermanentSuppressor();
    }

    protected void GRZQueuePermanentSuppressor()
    {
        if (!g_Game.IsServer())
            return;
        m_GRZSFGSuppressorAttempts = 0;
        g_Game.GetCallQueue(CALL_CATEGORY_GAMEPLAY).Remove(GRZEnsurePermanentSuppressor);
        g_Game.GetCallQueue(CALL_CATEGORY_GAMEPLAY).CallLater(GRZEnsurePermanentSuppressor, 100, false);
    }

    void GRZEnsurePermanentSuppressor()
    {
        if (!g_Game.IsServer())
            return;
        int slot = InventorySlots.GetSlotIdFromString("UAV_SFG_Suppressor");
        if (slot < 0)
            return;
        EntityAI suppressor = FindAttachmentBySlotName("UAV_SFG_Suppressor");
        if (!suppressor)
        {
            GetInventory().SetSlotLock(slot, false);
            suppressor = GetInventory().CreateAttachmentEx("UAV_SFG_Sup", slot);
        }
        if (suppressor)
        {
            GetInventory().SetSlotLock(slot, true);
            return;
        }
        m_GRZSFGSuppressorAttempts++;
        if (m_GRZSFGSuppressorAttempts < 5)
            g_Game.GetCallQueue(CALL_CATEGORY_GAMEPLAY).CallLater(GRZEnsurePermanentSuppressor, 250, false);
        else
            Error("SFG permanent suppressor: attachment could not be created. Check UAV_SFG_Sup config and slot.");
    }

    override bool CanReleaseAttachment(EntityAI attachment)
    {
        if (attachment && attachment.IsKindOf("SFG_Suppressor_Base"))
            return false;
        return super.CanReleaseAttachment(attachment);
    }

    override void EEDelete(EntityAI parent)
    {
        if (g_Game)
            g_Game.GetCallQueue(CALL_CATEGORY_GAMEPLAY).Remove(GRZEnsurePermanentSuppressor);
        super.EEDelete(parent);
    }
};