////////////////////////////////////////////////////////////////////
//DeRap: SFG50\SFG\proxy\config.bin
//Produced from mikero's Dos Tools Dll version 10.21
//https://mikero.bytex.digital/Downloads
//'now' is Wed Nov 04 03:50:04 2026 : 'file' last modified on Sat Oct 24 21:26:39 2026
////////////////////////////////////////////////////////////////////

#define _ARMA_

class CfgPatches
{
	class UAV_SFG_Suppressor
	{
		units[] = {"UAV_SFG_Sup"};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] = {"DZ_Data"};
	};
};
class cfgVehicles
{
	class ItemSuppressor;
	class SFG_Suppressor_Base: ItemSuppressor
	{
		scope = 1;
		model = "UAVWEAPONS\SFG50\SFG\proxy\suppressor.p3d";
		rotationFlags = 17;
		reversed = 0;
		weight = 70;
		itemSize[] = {3,1};
		itemModelLength = 0.176;
		barrelArmor = 1500;
		lootCategory = "Attachments";
		hiddenSelections[] = {"camo"};
		inventorySlot[] = {"UAV_SFG_Suppressor"};
		simulation = "ItemSuppressor";
		noiseShootModifier = -0.9;
		recoilModifier[] = {0.8,0.8,0.8};
		swayModifier[] = {1,1,1};
		selectionFireAnim = "zasleh";
		soundIndex = 1;
		muzzlePos = "usti hlavne";
		class Particles
		{
			class OnFire
			{
				class MuzzleFlash
				{
					overrideParticle = "weapon_shot_fnx_02";
					onlyWithinHealthLabel[] = {0,3};
				};
				class Ruined
				{
					onlyWithinHealthLabel[] = {4,4};
					illuminateWorld = 1;
				};
			};
			class OnOverheating
			{
				shotsToStartOverheating = 2;
				maxOverheatingValue = 10;
				overheatingDecayInterval = 1;
				class SmokingBarrel
				{
					overrideParticle = "smoking_barrel_small";
					onlyWithinRainLimits[] = {0,0.2};
				};
				class SmokingBarrelHotSteamSmall
				{
					overrideParticle = "smoking_barrel_steam_small";
					positionOffset[] = {0,0.1,0};
					onlyWithinRainLimits[] = {0.2,1};
				};
			};
		};
		class DamageSystem
		{
			class GlobalHealth
			{
				class Health
				{
					hitpoints = 2500;
					healthLevels[] = {{1,{"UAVWEAPONS\SFG50\SFG\data\suppressor.rvmat"}},{0.7,{"UAVWEAPONS\SFG50\SFG\data\suppressor.rvmat"}},{0.5,{""}},{0.3,{""}},{0,{""}}};
				};
			};
		};
	};
	class UAV_SFG_Sup: SFG_Suppressor_Base
	{
		scope = 2;
		displayName = "SFG Suppressor";
		descriptionShort = "SFG Suppressor";
		hiddenSelectionsTextures[] = {"UAVWEAPONS\SFG50\SFG\data\suppressor.paa"};
		hiddenSelectionsMaterials[] = {"UAVWEAPONS\SFG50\SFG\data\suppressor.rvmat"};
	};
};
class CfgNonAIVehicles
{
	class ProxyAttachment;
	class Proxysuppressor: ProxyAttachment
	{
		scope = 2;
		inventorySlot = "UAV_SFG_Suppressor";
		model = "UAVWEAPONS\SFG50\SFG\proxy\suppressor.p3d";
	};
};
class CfgSlots
{
	class Slot_UAV_SFG_Suppressor
	{
		name = "UAV_SFG_Suppressor";
		displayName = "SFG Suppressor";
		ghostIcon = "supressor";
	};
};
