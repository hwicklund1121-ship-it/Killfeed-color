# GRZ InstaDrop v0.4.4 transition continuation test

The v0.4.3 log confirms preparation is lost during the drop. The previous
exception never logged an acceptance: its stance/angle/weapon gates were too
late or another gate failed. The log does not identify the exact rejected gate.

This build arms a 900ms window when a ready, uncharged firearm user receives an
accepted stand/crouch-to-prone request. A native raise cancellation may be
excepted during that window, including before the prone side pose settles.
Outside the window the existing prone-side angle requirement remains.
It uses the actual movement/weapon handles and Weapon_Base plus FIREARMS
behavior rather than requiring a particular rifle subclass/command integer.
Actual charge/release, attack, gear, native clearance, action, emote and weapon
operation restrictions remain. This can retain the ready pose if aiming is
pressed immediately after a requested drop; G/native explicit cancellation
still runs. No forced input, mode restart, aim change or forced landing pose.

Every native continuation rejection now logs its gates BEFORE returning.
CancelThrowing logs separately. This distinguishes a script cancellation from
loss of native weapon mode without that cancellation call. The animation graph,
roll routes, 0.22 drop blend and 0.24 roll-to-stand timing match v0.4.3 exactly.
The normal stance callback and weapon animation refresh are unchanged: the same
refresh also existed in historical pre-1.27 source, so a new 1.30 reset is unproven.

## Install
Close DayZ and stop the server. Extract into a fresh folder, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Restart both. Requires current supported DayZ 1.30.164.289 and GRZ Movement local
setup. The installer hash-checks game files, builds the graph locally, backs up
and installs client/server. No native game assets or private logs are shipped.

Test G -> lift -> look right -> prone. Verify gun pose, side landing, both rolls,
standing, G cancellation, gear/inventory, charge/release and normal aiming.
Check another client's view. If it fails, send the newest client script log:
look for `ready drop window armed`, `continuation native=false`, and
`CancelThrowing`. No in-game validation or Enforce compilation was possible here.
This is a timing-scope test, not a confirmed fix or reference animation match.
Mods that add CanContinueThrowing rejection rules may overlap this exception;
universal movement-mod compatibility is not claimed.

## Restore
Close both and run Restore-InstaDrop.ps1 -BackupPath with a known working backup.
