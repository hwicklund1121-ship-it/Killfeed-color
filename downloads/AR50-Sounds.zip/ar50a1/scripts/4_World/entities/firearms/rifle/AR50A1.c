class AR50A1_Base extends BoltActionRifle_InnerMagazine_Base
{
	override RecoilBase SpawnRecoilObject()
	{
		return new CZ527Recoil(this);
	}
};

class AR50A1_BLACK: AR50A1_Base{};
