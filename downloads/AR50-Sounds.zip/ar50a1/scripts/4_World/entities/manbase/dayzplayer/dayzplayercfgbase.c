modded class ModItemRegisterCallbacks
{
	override void RegisterFireArms(DayZPlayerType pType, DayzPlayerItemBehaviorCfg pBehavior)
	{
		super.RegisterFireArms(pType, pBehavior);
		
		pType.AddItemInHandsProfileIK("AR50A1_Base", "dz/anims/workspaces/player/player_main/weapons/player_main_mosin1903.asi", pBehavior, "dz/anims/anm/player/ik/weapons/mosin9130.anm", "dz/anims/anm/player/reloads/Mosin_1903/w_mosin1903_states.anm");
	};
};