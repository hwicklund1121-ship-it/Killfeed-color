////////////////////////////////////////////////////////////////////
//DeRap: ar50a1\ar50\config.bin
//Produced from mikero's Dos Tools Dll version 10.21
//https://mikero.bytex.digital/Downloads
//'now' is Wed Nov 04 03:49:57 2026 : 'file' last modified on Sat Oct 24 21:26:43 2026
////////////////////////////////////////////////////////////////////

#define _ARMA_

class CfgPatches
{
	class AR50A1
	{
		units[] = {};
		weapons[] = {"UAV_AR50A1"};
		requiredVersion = 0.1;
		requiredAddons[] = {"DZ_Data","DZ_Weapons_Firearms","DZ_Weapons_Ammunition","DZ_Weapons_Magazines"};
		magazines[] = {};
		ammo[] = {};
	};
};
class Mode_Safe;
class Mode_SemiAuto;
class OpticsInfoRifle;
class cfgWeapons
{
	class BoltActionRifle_InnerMagazine_Base;
	class AR50A1_Base: BoltActionRifle_InnerMagazine_Base
	{
		scope = 0;
		descriptionShort = "The ArmaLite AR-50 is a 20MM Bolt Action Sniper Rifle That Will Destroy Anything In It's Path";
		model = "UAVWEAPONS\ar50a1\ar50\data\AR50A1.p3d";
		weight = 13500;
		WeaponLength = 1;
		itemSize[] = {10,2};
		DisplayMagazine = 0;
		dexterity = 1.8;
		absorbency = 0.1;
		repairableWithKits[] = {5,1};
		repairCosts[] = {30,25};
		discreteDistance[] = {100,200,300,400,500,600,700,800,900,1000,1100};
		discreteDistanceInitIndex = 0;
		modelOptics = "-";
		distanceZoomMin = 100;
		distanceZoomMax = 100;
		PPDOFProperties[] = {1,0.5,50,180,4,10};
		optics = 1;
		opticsFlare = 0;
		value = 0;
		chamberedRound = "";
		chamberSize = 5;
		simpleHiddenSelections[] = {};
		attachments[] = {"weaponOptics","weaponOpticsHunting","weaponWrap"};
		canReceiveHuntingOptic = 1;
		chamberableFrom[] = {"UAV_Ammo_VULCAN"};
		magazines[] = {};
		magazineSwitchTime = 0.25;
		barrelArmor = 3000;
		ejectType = 1;
		recoilModifier[] = {1,3,2};
		reloadAction = "ReloadSVD";
		modes[] = {"SemiAuto"};
		class SemiAuto: Mode_SemiAuto
		{
			soundSetShot[] = {"ar50_Shot_SoundSet","ar50_Shot_SoundSet","ar50_Shot_SoundSet"};
			reloadTime = 1.0;
			recoil = "recoil_AKM";
			recoilProne = "recoil_AKM_prone";
		};
		class Particles
		{
			class OnFire
			{
				class MuzzleFlash
				{
					ignoreIfSuppressed = 1;
					overrideParticle = "weapon_shot_cz527_01";
				};
				class SmokeCloud
				{
					overrideParticle = "weapon_shot_winded_smoke";
				};
			};
			class OnOverheating
			{
				shotsToStartOverheating = 5;
				maxOverheatingValue = 20;
				overheatingDecayInterval = 1;
			};
			class OnBulletCasingEject
			{
				class ChamberSmokeRaise
				{
					overrideParticle = "weapon_shot_chamber_smoke_raise";
					overridePoint = "Nabojnicestart";
				};
			};
		};
		class OpticsInfo: OpticsInfoRifle
		{
			memoryPointCamera = "eye";
			modelOptics = "-";
			distanceZoomMin = 100;
			distanceZoomMax = 100;
			discreteDistance[] = {100,200,300,400,500,600,700,800,900,1000};
			discreteDistanceInitIndex = 0;
		};
		class AnimEvents
		{
			class SoundWeapon
			{
				class walkErc_L
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 1;
				};
				class walkErc_R
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_R_SoundSet";
					id = 2;
				};
				class runErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 3;
				};
				class runErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_R_SoundSet";
					id = 4;
				};
				class sprintErc_L
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 5;
				};
				class sprintErc_R
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 6;
				};
				class walkCro_L
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 21;
				};
				class walkCro_R
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 22;
				};
				class runCro_L
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 23;
				};
				class runCro_R
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 24;
				};
				class walkProne_L
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 31;
				};
				class walkProne_R
				{
					soundSet = "Weapon_Movement_HRifle_walkCro_SoundSet";
					id = 32;
				};
				class runProne_L
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 33;
				};
				class runProne_R
				{
					soundSet = "Weapon_Movement_HRifle_runCro_SoundSet";
					id = 34;
				};
				class jumpErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 35;
				};
				class jumpErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 36;
				};
				class landFootErc_L
				{
					soundSet = "Weapon_Movement_HRifle_landFootErc_SoundSet";
					id = 37;
				};
				class landFootErc_R
				{
					soundSet = "Weapon_Movement_HRifle_landFootErc_SoundSet";
					id = 38;
				};
				class walkRasErc_L
				{
					soundSet = "Weapon_Movement_HRifle_walkRasErc_SoundSet";
					id = 51;
				};
				class walkRasErc_R
				{
					soundSet = "Weapon_Movement_HRifle_walkRasErc_SoundSet";
					id = 52;
				};
				class runRasErc_L
				{
					soundSet = "Weapon_Movement_HRifle_runRasErc_SoundSet";
					id = 53;
				};
				class runRasErc_R
				{
					soundSet = "Weapon_Movement_HRifle_runRasErc_SoundSet";
					id = 54;
				};
				class HandStep_L
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 61;
				};
				class HandStep_R
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 62;
				};
				class HandStep_Hard_L
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 63;
				};
				class HandStep_Hard_R
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 64;
				};
				class landFeetErc
				{
					soundSet = "Weapon_Movement_HRifle_landFeetErc_SoundSet";
					id = 100;
				};
				class Weapon_Movement_HRifle_Walk
				{
					soundSet = "Weapon_Movement_HRifle_walkErc_L_SoundSet";
					id = 101;
				};
				class Weapon_Movement_HRifle_Run
				{
					soundSet = "Weapon_Movement_HRifle_runErc_L_SoundSet";
					id = 102;
				};
				class Weapon_Movement_HRifle_Sprint
				{
					soundSet = "Weapon_Movement_HRifle_sprintErc_SoundSet";
					id = 103;
				};
				class Weapon_Movement_HRifle_Land
				{
					soundSet = "Weapon_Movement_HRifle_landFeetErc_SoundSet";
					id = 104;
				};
				class Char_Gestures_Hand_Grab_Rifle
				{
					soundSet = "Char_Gestures_Hand_Grab_FabricRifle_SoundSet";
					id = 892;
				};
			};
		};
		class DamageSystem
		{
			class GlobalHealth
			{
				class Health
				{
					hitpoints = 10000;
					healthLevels[] = {{1,{"UAVWEAPONS\ar50a1\ar50\data\AR50.rvmat","UAVWEAPONS\ar50a1\ar50\data\MUZZLE.rvmat"}},{0.7,{"UAVWEAPONS\ar50a1\ar50\data\AR50.rvmat","UAVWEAPONS\ar50a1\ar50\data\MUZZLE.rvmat"}},{0.5,{"UAVWEAPONS\ar50a1\ar50\data\AR50_damage.rvmat","UAVWEAPONS\ar50a1\ar50\data\MUZZLE_damage.rvmat"}},{0.3,{"UAVWEAPONS\ar50a1\ar50\data\AR50_damage.rvmat","UAVWEAPONS\ar50a1\ar50\data\MUZZLE_damage.rvmat"}},{0,{"UAVWEAPONS\ar50a1\ar50\data\AR50_destruct.rvmat","UAVWEAPONS\ar50a1\ar50\data\MUZZLE_destruct.rvmat"}}};
				};
			};
		};
	};
	class UAV_AR50A1: AR50A1_Base
	{
		scope = 2;
		displayName = "AR50A1";
		hiddenSelectionsTextures[] = {"UAVWEAPONS\ar50a1\ar50\data\AR50_CO.paa","UAVWEAPONS\ar50a1\ar50\data\MUZZLE_CO.paa"};
		hiddenSelectionsMaterials[] = {"UAVWEAPONS\ar50a1\ar50\data\AR50.rvmat","UAVWEAPONS\ar50a1\ar50\data\MUZZLE.rvmat"};
	};
};
class cfgSoundsets
{
	class Rifle_Shot_Base_SoundSet;
	class ar50_Shot_SoundSet: Rifle_Shot_Base_SoundSet
	{
		soundShaders[] = {"ar50_Shot_closeShot_SoundShader","ar50_Shot_midShot_SoundShader","ar50_Shot_distShot_SoundShader"};
	};
};
class CfgSoundShaders
{
	class ar50_Shot_closeShot_SoundShader
	{
		samples[] = {{"UAVWEAPONS\ar50a1\ar50\data\AR50_Shot",1},{"UAVWEAPONS\ar50a1\ar50\data\AR50_Shot",1},{"UAVWEAPONS\ar50a1\ar50\data\AR50_Shot",1}};
		volume = 0.25;
		range = 75;
		rangeCurve = "closeShotCurve";
	};
	class ar50_Shot_midShot_SoundShader
	{
		samples[] = {{"UAVWEAPONS\ar50a1\ar50\data\AR50_Shot",1},{"UAVWEAPONS\ar50a1\ar50\data\AR50_Shot",1},{"UAVWEAPONS\ar50a1\ar50\data\AR50_Shot",1}};
		volume = 0.2;
		range = 600;
		rangeCurve = "midShotCurve";
	};
	class ar50_Shot_distShot_SoundShader
	{
		samples[] = {{"UAVWEAPONS\ar50a1\ar50\data\AR50_Shot",1},{"UAVWEAPONS\ar50a1\ar50\data\AR50_Shot",1},{"UAVWEAPONS\ar50a1\ar50\data\AR50_Shot",1}};
		volume = 0.18;
		range = 1200;
		rangeCurve = "farShotCurve";
	};
};
