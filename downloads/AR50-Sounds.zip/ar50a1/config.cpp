////////////////////////////////////////////////////////////////////
//DeRap: ar50a1\config.bin
//Produced from mikero's Dos Tools Dll version 10.21
//https://mikero.bytex.digital/Downloads
//'now' is Wed Nov 04 03:49:57 2026 : 'file' last modified on Sat Oct 24 21:26:43 2026
////////////////////////////////////////////////////////////////////

#define _ARMA_

class CfgPatches
{
	class ar50a1
	{
		requiredAddons[] = {"DZ_Data","DZ_Characters_Vests","DZ_Scripts","DZ_Characters"};
		units[] = {};
		weapons[] = {};
	};
};
class CfgMods
{
	class ar50a1
	{
		dir = "ar50a1";
		picture = "";
		action = "";
		hideName = 1;
		hidePicture = 1;
		name = "ar50a1";
		credits = "UAV7";
		author = "UAV";
		authorID = "0";
		version = "1.0";
		extra = 0;
		type = "mod";
		dependencies[] = {"World"};
		class defs
		{
			class worldScriptModule
			{
				value = "";
				files[] = {"UAVWEAPONS/ar50a1/scripts/4_World"};
			};
		};
	};
};
