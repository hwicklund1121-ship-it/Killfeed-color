@echo off
cd /d "%~dp0"
if not exist "DayZServer_x64.exe" (
 echo Put these files in your installed DayZ Server folder beside DayZServer_x64.exe.
 pause
 exit /b 1
)
rem Editor Loader dependencies stay in their own server mod folders.
if not exist "%~dp0@Dabs Framework\Addons\*.pbo" (
 echo Missing Dabs Framework: expected @Dabs Framework\Addons beside this BAT.
 pause
 exit /b 1
)
if not exist "%~dp0@DayZ Editor Loader\Addons\*.pbo" (
 echo Missing Editor Loader: expected @DayZ Editor Loader\Addons beside this BAT.
 pause
 exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup-GRZEmptyWorld.ps1"
if errorlevel 1 (
 pause
 exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup-VPPAdmin.ps1"
if errorlevel 1 (
 pause
 exit /b 1
)
DayZServer_x64.exe -config=serverDZ.cfg -port=2302 "-profiles=profiles" "-mod=@CF;@Dabs Framework;@DayZ Editor Loader;@VPPAdminTools;@GRZ_Local;@GRZ_Customs" -dologs -adminlog
pause
