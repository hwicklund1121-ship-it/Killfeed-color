# GRZ InstaDrop v0.3.10 landing-lean test on v0.3.8

Explicit baseline: v0.3.8, as requested. Keeps its roll/spin routes, native
clips, body-drop entry, gun-hold layer, 0.22-second drop blend, 0.24-second stand
blend, native roll selector and active-roll guards. The v0.3.9 roll-route
experiment is NOT included.

Changes only the three pitch rows in GRZDropDirectionalPose: swaps the left
and right side sample values. Center/back samples and camera input variables
stay unchanged. This targets the opposite lean shown in the user's right-look
screenshot. It does not add smoothing, change timing or alter native keyframes.
The intent is to preserve the v0.3.8 motion and correct the landing orientation.
Actual lean, overlay behavior and preservation of the approved feet require
in-game comparison; source checks alone cannot establish the visual result.

## Install

Keep the working v0.3.8 ZIP. Close DayZ and stop the server. Extract this test
to a new folder, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires the existing DayZ 1.30.164.289 / GRZ Movement local setup. The graph
is built locally from hash-checked game files; native graph and animation
payloads are not distributed. Installer backs up all three PBOs on both sides.
Startup should identify `v0.3.10 graph selected` and the v0.3.8 baseline.

## Compare

Repeat the screenshot sequence looking right and check the landing leans the
other way. Check left-look and forward-look as well, then confirm the gun hold,
body drop, spin after landing and stand-up still match v0.3.8. Check both roll
directions, first/third person and another client. Send a current-build clip
if the lean is unchanged or the legs differ. The native gun-hold layer may
also influence the body; this test does not claim per-bone isolation.

## Restore

Close both sides and use the exact backup folder printed by the installer:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL BACKUP FOLDER"
```
