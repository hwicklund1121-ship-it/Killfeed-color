name = "GRZ Hitmarker";
author = "GRZ";
version = "0.1.5";
overview = "Server-confirmed hitmarkers with settings under Options > Game.";
