# GRZ InstaDrop v0.3.5 side/back drop test

Built from the supplied v0.3.2 package and installed graph.

Slows drop blending from 0.14 to 0.22 seconds and direct/roll stand-up blending
from 0.16 to 0.24 seconds. Keeps v0.3.2 foot/roll clips, roll guards, roll entry
and the 0.12-second minimum roll segment. These are blend durations, not measured
complete action durations.
Retains the v0.3.3 directional drop-pose test: the forward-look samples in all
three pitch rows select the existing back endpoint rather than the center
front-prone samples. Left/right pose samples are swapped at all pitch rows: looking right should
land on the left side, and looking left should land on the right side. AimX
and AimY inputs themselves are unchanged. Anatomy still requires gameplay validation.
The intent is side/back selection by look direction without a stomach snap.
This is an unverified gameplay test, not a confirmed camera fix. Native pose
interpolation, anatomical direction and first/third-person motion need testing.
No camera angles, input bindings or movement speeds are written by this patch.

## Install

Close DayZ and stop the server. Extract this ZIP to a new folder and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires the same DayZ 1.30.164.289 and existing GRZ Movement local setup as
v0.3.2. The installer builds from the local vanilla game files, checks the
expected hash, backs up and installs all three InstaDrop PBOs on both sides.
Native animation graphs and animations are not distributed in this ZIP.
The script log should identify `v0.3.5 graph selected`.

## Test

With G gun-lift active, fast-drop looking forward, left and right. Check for a
side/back landing and whether the ground-facing dip remains. Repeat at level,
upward and downward aim. Verify roll continuity and mid-roll stand still work;
compare first/third person and another player's view. Send a short clip if the
body or view still snaps down. Source/package checks do not establish gameplay.

## Restore

Close both sides, then run using the backup path printed by the installer:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL BACKUP FOLDER"
```
