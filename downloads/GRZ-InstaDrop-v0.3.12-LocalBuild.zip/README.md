# GRZ InstaDrop v0.3.12 direct native side-landing test

Target: looking right should land directly in the native left-side aiming pose,
like aiming from the back while looking left. The oversized reference video
could not be transferred/viewed; this build follows the user's text description.

Replaces only the v0.3.11 directional pose node with a zero-time selector and
two native pose nodes. Right/neutral AimX selects the fixed native -90-degree
side sample; negative AimX selects the +90-degree sample. Pitch remains AimY.
The table uses the existing native AimToBack source, but fixed X values mean
only its side samples are evaluated, not horizontal center/front/back samples.
No interpolation between opposing side branches is requested by this selector.
The ordinary drop-to-side transition still blends for 0.22 seconds.

All graph bytes outside that directional pose block remain identical to
v0.3.11. Keeps the v0.3.6 roll/stance baseline, native clips and guards, and
0.24-second stand blend. Forced on-back entry and the on-back hold overlay
remain removed. No new animation assets, camera angles or input keys are added.

## Install

Close DayZ and stop the server. Extract to a fresh folder and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires the existing DayZ 1.30.164.289 / GRZ Movement local setup. Graphs are
built locally from hash-checked game files; no native graph/animation assets
are redistributed. Installer backups and rollback remain. Startup should
identify `v0.3.12 graph selected` and direct native side-pose selector test.

## Check

Test G -> look right -> drop. Check it lands on the left side directly, then
check both roll directions, foot spin and normal mid-roll standing. Compare
left and neutral inputs, pitch angles, first/third person and another client.
The selector changes sides immediately when AimX crosses zero; test for a
visible snap when changing look direction while lying down. Native pose
anatomy, graph loading and runtime entry still require in-game verification.
Removing the back-hold overlay may leave the earlier gun-alignment issue.
If the result is still wrong, send a 2-5 second current-build clip under 32 MB.

## Restore

Close both sides and use the exact backup folder printed by the installer:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL BACKUP FOLDER"
```
