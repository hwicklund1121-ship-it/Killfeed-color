# GRZ InstaDrop 1.27 animation comparison exporter

This is a read-only comparison/export tool, not another gameplay build. It reads
25 selected clips from your downloaded 1.27 player animation archive and the
current installed player animation archive. It hashes both versions and exports
only the selected old clips plus REPORT.json. It does not change game/server
files, install addons, contact a network service or request Steam credentials.

The two smaller uploaded archives were readable, but the whole player archive
exceeded the executor's 32 MiB transfer limit. Matching paths/GUIDs in the old
and new ASIs cannot prove the animation bytes are identical; this tool compares
the actual decompressed clips. GRAPH-FINDINGS.json records the graph findings.

## Run on Windows

Extract this tool ZIP to its own folder. Open PowerShell in that folder and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Export-InstaDrop-127Clips.ps1
```

A file picker opens. Select the DOWNLOADED OLD file:

```text
DayZ-1.27\Addons\anims_anm_player.pbo
```

Current game defaults to the known Steam location. For another installation:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Export-InstaDrop-127Clips.ps1 -GamePath "D:\SteamLibrary\steamapps\common\DayZ"
```

The old archive can also be passed with -OldPlayerPbo instead of the picker.

Upload every `GRZ-127-Clips-...-part*.zip` created in the tools folder by this
run. The console prints their exact paths. Each ZIP stays under 32 MiB by
limiting the uncompressed animation data to 24 MiB per part. Temporary staging
files created by this run are removed after export; your original archives
are kept. Only old clips and content hashes are included, not current clips
or your account details/absolute local paths.

## Limits

This exports the old binary ANMs for inspection, not editable source rigs.
Identical bytes rule out a clip-content difference for those selected resources,
but do not establish identical engine, script or mod behavior. Different bytes
identify assets to investigate, not proof of the source of the reference motion.
The old graph grammar differs from 1.30, so copying the old workspace into live
Addons is not a verified migration. The exporter has not been run on Windows
here; its PBO reader is derived from the local builder already used in-session.
Native graph/animation payloads are not distributed in this tools download.
