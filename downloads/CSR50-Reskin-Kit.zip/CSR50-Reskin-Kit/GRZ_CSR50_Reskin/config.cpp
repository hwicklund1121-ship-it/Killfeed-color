// Reskin-only example. Requires the original CSR50 weapon addon.
class CfgPatches
{
 class GRZ_CSR50_Reskin
 {
  units[] = {};
  weapons[] = {"GRZ_CSR50_Reskin"};
  requiredVersion = 0.1;
  requiredAddons[] = {"CSR50_Base"};
 };
};
class CfgWeapons
{
 class UAV_CSR50;
 class GRZ_CSR50_Reskin: UAV_CSR50
 {
  scope = 2;
  displayName = "CSR50 Reskin";
  hiddenSelections[] = {"zbytek", "camo"};
  hiddenSelectionsTextures[] = {"GRZ_CSR50_Reskin\data\part1_co.paa", "GRZ_CSR50_Reskin\data\part1_co.paa"};
  hiddenSelectionsMaterials[] = {"GRZ_CSR50_Reskin\data\part1.rvmat", "GRZ_CSR50_Reskin\data\part1.rvmat"};
 };
};
