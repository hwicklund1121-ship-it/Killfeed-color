# GRZ InstaDrop v0.4.0 native throw-chain comparison baseline

The supplied comparison contains 25 selected native 1.27 clips. All 25 match
current DayZ 1.30.164.289 byte-for-byte; the uploaded clip payload hashes were
independently checked against the report. The selected old animation data is
already present in the current game. This does not cover every asset or rule
out engine/script changes or movement mods used by the reference server.

The old graph keeps ThrowStrengthIdleB fully weighted at 1.0 and uses the
native stance/angle strength chain. Our prototypes replaced that behavior with
fixed landing poses. This baseline removes those experiments and preserves the
current native throw chain, whose relevant setup also appears in the old graph.
It is an evidence-based comparison build, not a claimed exact reference match.

## Resulting setup

- Original native throw strength/idle/intro/movement and angle selection.
- No custom side tables, fixed side angles, forced direct back landing or
  on-back aim overlays. Original stance transition states are retained.
- Native gun-lift blend 0.3 seconds. Earlier forced 0.22 drop and direct
  stand-up routing are removed. Existing roll-to-standing helper remains 0.24.
- Existing firearm stance/roll permissions, roll-entry/standing routes,
  minimum 0.12-second roll segment, active-roll guards and single-direction
  roll selector remain. Runtime branch selection still needs testing.
- GRZ Movement and its gait/camera setup remain in place. This package adds
  no animation payloads or clip-speed overrides.

## Install

Close DayZ and stop the server. Keep a working earlier ZIP/backup. Extract to
a new folder and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires the current DayZ 1.30.164.289 / GRZ Movement local setup. The installer
builds from hash-checked current game files; it does not require the downloaded
1.27 archives. Native game assets, old graphs and uploaded reports are not
redistributed. Backups and rollback remain. Startup should identify
`v0.4.0 graph selected` and native throw/strength chain restored.

## Compare against the reference

Confirm menu/login loads without graph errors. Stand still: G -> wait for gun
lift -> look right -> prone. Hold the landing before rolling or standing. Then
repeat during gun lift and while moving. Record drop, gun hold, both roll
directions and mid-roll stand in first/third person and from another client.
Compare actual pose and motion with the supplied reference; native direction
selection is restored, so no arbitrary left-side result is forced by this build.
Also check normal stance controls and charge/cancel/release.

Source/package checks passed. Native engine loading, physical stance behavior,
visible pose/foot spin and multiplayer playback have not been tested here. If
the result still differs, the next comparison should isolate engine/input/mod
behavior, not assume these 25 native clips are missing or different.

## Restore

Close both sides and run with a backup known to contain a working build:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL WORKING-BUILD BACKUP FOLDER"
```
