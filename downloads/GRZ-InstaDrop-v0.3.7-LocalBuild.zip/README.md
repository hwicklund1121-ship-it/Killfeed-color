# GRZ InstaDrop v0.3.7 on-back gun-hold test

Based on the approved v0.3.6. The prepared-prone states now use a new blend
with GRZDropDirectionalPose as base and the native PoBAimB2 as aim layer.
This follows the existing native PoBAimB topology and reuses Throw.PoB.AimPose,
confirmed by the supplied rifle ASI binding to the on-back throw aimspace.
The intent is to restore the on-back gun hold on the initial drop.

The directional pose table, native roll clips, single-direction roll selector,
roll guards, drop blend (0.22), stand blend (0.24), actual throwing/release and
stance/roll policy logic remain unchanged. No new animations are included.

Important validation limit: ASI and AST files identify animation resources but
do not expose their per-bone tracks. The overlay may also influence the body;
unchanged base nodes do not prove unchanged leg playback. Native graph loading,
gun alignment and preservation of the approved foot motion require DayZ tests.

## Install

Keep the working v0.3.6 ZIP. Close DayZ and stop the server, extract this ZIP to
a fresh folder, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires the existing DayZ 1.30.164.289 / GRZ Movement local setup. The graph
is built locally from hash-checked game files. Native graphs, ASI/AST and
animation payloads are not distributed. Installer backs up all three PBOs on
both sides. Startup should identify `v0.3.7 graph selected` and gun-hold test.

## Compare with v0.3.6

Test G -> initial drop looking forward/right/left: check that the gun uses the
on-back hold rather than pointing straight out. Then test the previously
approved roll and stand sequence in first/third person and from another client.
Confirm feet/legs still spin smoothly, opposite-side landings remain correct,
and drop/stand timing is unchanged. Also check ordinary gun-lift while standing
and crouching, and charge/cancel/release. If the body or feet change, restore
v0.3.6 and send a short comparison clip; this overlay is an unverified test.

## Restore

Close both sides and use the exact backup folder printed by the installer:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL BACKUP FOLDER"
```
