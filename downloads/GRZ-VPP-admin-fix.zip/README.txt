Stop the server. Extract Setup-VPPAdmin.ps1 beside DayZServer_x64.exe, replacing the older script. Open PowerShell in that server folder and run:

powershell -NoProfile -ExecutionPolicy Bypass -File .\Setup-VPPAdmin.ps1

Restart the server and DayZ afterward. The script uses your locally saved admin-owner.local.txt, or asks for your SteamID64 if it is absent. It preserves all valid existing admin IDs and removes blank lines/BOM that prevent VPP from loading them. It does not change your password/credentials file.
