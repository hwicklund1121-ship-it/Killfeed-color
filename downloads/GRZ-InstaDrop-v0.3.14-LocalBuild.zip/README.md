# GRZ InstaDrop v0.3.14 native side-hold / entry test

The current/reference videos show different motion: the current clip goes
belly-first and changes sharply through roll/stand, while the reference carries
the gun close through more continuous side/back movement. The previous pose
changes addressed only the prepared idle machine; intro and movement have
separate native routes. Video alone cannot establish the active graph state.

This build makes three connected changes:
- Uses native ThrowPoBIdleG plus Throw.PoB.AimPose, matching the stock PoBAimB
  base/aim topology, instead of locomotive rifle-prone aiming samples.
- Right/neutral input chooses fixed native lateral aim -45.0; left input chooses
  +45.0. Both are FLOAT expressions. Prepared prone starts in the native tagged
  PoB state consistently, including when it initializes already prone.
- Adds intro/movement -> prepared idle routes on an actual stance change to
  prone while ActionProgress is zero and the throw command is prepare (0).
  These blend for 0.22 seconds. Native charge/release/cancel paths remain.

Native roll nodes/clips, direction selector, roll guards and 0.24 stand blend
are retained. The tagged state can affect which native roll branch is chosen.
No old 1.27 graph or animation tracks are recreated, and there is no guaranteed
visual match. Source/package checks cannot establish runtime body or foot motion.

## Install

Close DayZ and stop the server. Extract into a new folder and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-InstaDrop.ps1
```

Requires the existing DayZ 1.30.164.289 / GRZ Movement local setup. Graphs are
built from hash-checked local game files. Native graph/animation payloads and
uploaded videos/logs are not redistributed. Backups and rollback remain.
Startup should identify `v0.3.14 graph selected` and intro/movement entry test.

## Check in this order

1. Confirm menu/login loads and the fresh RPT/error log has no graph errors.
2. Stand still, tap G, WAIT until the gun lift finishes, look right, then drop.
   Hold the resulting pose briefly before pressing any roll/stand controls.
3. Repeat while pressing prone during the gun lift, then while moving.
4. Test both roll directions and stand during the roll; check gun/feet together.
5. Verify ordinary stance and charge/cancel/release, first/third person and
   another client. Send the current-build clip and fresh script/RPT if motion
   still differs. These separate tests identify the phase still producing it.

The native side-aim pose may still appear too reclined, and a sign change can
snap between sides. Graph loading and animation playback have not been tested
in DayZ here. Keep a working earlier ZIP and backup for comparison.

## Restore

Close both sides and run with a backup known to contain a working build:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Restore-InstaDrop.ps1 -BackupPath "FULL WORKING-BUILD BACKUP FOLDER"
```
